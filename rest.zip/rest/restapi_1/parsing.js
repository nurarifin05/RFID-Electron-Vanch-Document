var Tag = "453230303030314133313037303135323235373037373530453230303030314133313037303135323235373037373530453230303030314133313037303135323235373037373530000001";
var i;
var panjang;
var jadi;
var Id;
var Reader;
target = [];

for (const array=Array.from(Tag);array.length;target.push(array.splice(0,48).join('')));
panjang = target.length-1;
console.log('panjang=',panjang);
console.log(target);


Id = target.slice(-1);
Reader = Id.toString();
// console.log('IDReader=',Reader)

function hex_to_ascii(str1){
    var hex = str1.toString();
    var str = '';
    for (var n = 0; n < hex.length; n+=2){
        str += String.fromCharCode(parseInt(hex.substr(n,2),16));
    }
    return str;
}

for(i=0;i<panjang;i++){
    jadi = target[i].toString();
    jadi = jadi.slice(0,48);
    
    // var kirimReader = (hex_to_ascii(Reader));
    var kirimTag = (hex_to_ascii(jadi));
    
    
    // console.log('hasil Konversi Tag:', kirimTag);
    // console.log('ID Reader:', Reader);

    var panjangTag = kirimTag.length;
    var panjangDeviceId = Reader.length;
    // console.log("panjang tag: ", panjangTag)

    if (panjangTag === 24 && panjangDeviceId === 6 ){
        console.log("qeury")
    }else{
        console.log("gagal")
    }
}












// var Tag = msg.payload;
// var i;
// var panjang;
// var jadi;
// var Id;
// var Reader;
// target = [];

// for (const array=Array.from(Tag);array.length;target.push(array.splice(0,48).join('')));
// panjang = target.length;
// console.log(target);
// console.log('panjang=',panjang);
// Id = target.slice(-1);
// Reader = Id.toString();
// console.log('IDReader=',Reader)

// function hex_to_ascii(str1){
//     var hex = str1.toString();
//     var str = '';
//     for (var n = 0; n < hex.length; n+=2){
//         str += String.fromCharCode(parseInt(hex.substr(n,2),16));
//     }
//     return str;
// }

// for(i=0;i<panjang;i++){
//     jadi = target[i].toString();
//     jadi = jadi.slice(0,48);
    
//     // var kirimReader = (hex_to_ascii(Reader));
//     var kirimTag = (hex_to_ascii(jadi));
    
//     console.log('hasil Konversi ID:', Reader);
//     console.log('Hasil Konversi Tag:', kirimTag);
    
//     msg.topic = "INSERT INTO reader(`Device_ID`, `tag_number`) VALUES ('"+Reader+"','"+kirimTag+"')";
//     return msg;
// }
