'use strict';
exports.ok = function(value, res){
    var data = (
         value
         
    );
    
    res.json(data);
    res.end();
};