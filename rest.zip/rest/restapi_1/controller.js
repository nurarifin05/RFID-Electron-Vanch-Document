'use strict';
var response = require('./res');
var connection = require('./conn');

exports.findUsers = function(req, res){
    var id = req.params.id;

    connection.query('SELECT DISTINCT Device_ID,tag_number, max(TimeStamp) TimeStamp  FROM reader WHERE date_format(TimeStamp,"%Y%j%H%i") = date_format(now(), "%Y%j%H%i") - ? group by Device_ID,tag_number', [parseInt(id)],

    function(error, rows, fields){
    if(error){
        console.log(error)}
        else{
            response.ok(rows, res)
        }
    });
};  