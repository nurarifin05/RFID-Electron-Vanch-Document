﻿namespace HwVx6330K
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.TabSheet_CMD = new System.Windows.Forms.TabPage();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.CloseNetPort = new System.Windows.Forms.Button();
            this.OpenNetPort = new System.Windows.Forms.Button();
            this.Edit_TCPIPAddr = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.Edit_TCPIPIP = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.Edit_TCPIPPort = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.ComboBox_baud2 = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.ComboBox_AlreadyOpenCOM = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ClosePort = new System.Windows.Forms.Button();
            this.OpenPort = new System.Windows.Forms.Button();
            this.Edit_CmdComAddr = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.ComboBox_COM = new System.Windows.Forms.ComboBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.ComboBox_Relay2 = new System.Windows.Forms.ComboBox();
            this.Button_Relay = new System.Windows.Forms.Button();
            this.ComboBox_Relay1 = new System.Windows.Forms.ComboBox();
            this.Button_ClearListBox = new System.Windows.Forms.Button();
            this.Button_GetListBox = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.button_gettigtime = new System.Windows.Forms.Button();
            this.button_settigtime = new System.Windows.Forms.Button();
            this.comboBox_tigtime = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.button_OffsetTime = new System.Windows.Forms.Button();
            this.comboBox_OffsetTime = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.Button_SetAccuracy = new System.Windows.Forms.Button();
            this.ComboBox_EASAccuracy = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.Button_SetWorkMode = new System.Windows.Forms.Button();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.Button_SetWGParameter = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.radioButton_band5 = new System.Windows.Forms.RadioButton();
            this.radioButton_band4 = new System.Windows.Forms.RadioButton();
            this.radioButton_band3 = new System.Windows.Forms.RadioButton();
            this.radioButton_band2 = new System.Windows.Forms.RadioButton();
            this.radioButton_band1 = new System.Windows.Forms.RadioButton();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.Button_DefaultParameter = new System.Windows.Forms.Button();
            this.Button_SetParameter = new System.Windows.Forms.Button();
            this.ComboBox_scantime = new System.Windows.Forms.ComboBox();
            this.ComboBox_baud = new System.Windows.Forms.ComboBox();
            this.CheckBox_SameFre = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ComboBox_dmaxfre = new System.Windows.Forms.ComboBox();
            this.ComboBox_dminfre = new System.Windows.Forms.ComboBox();
            this.ComboBox_PowerDbm = new System.Windows.Forms.ComboBox();
            this.Edit_NewComAdr = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Button_GetReaderInfo = new System.Windows.Forms.Button();
            this.Edit_scantime = new System.Windows.Forms.TextBox();
            this.EPCC1G2 = new System.Windows.Forms.CheckBox();
            this.ISO180006B = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ProtocolLabel = new System.Windows.Forms.Label();
            this.Edit_dmaxfre = new System.Windows.Forms.TextBox();
            this.Edit_powerdBm = new System.Windows.Forms.TextBox();
            this.Edit_Version = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Edit_dminfre = new System.Windows.Forms.TextBox();
            this.Edit_ComAdr = new System.Windows.Forms.TextBox();
            this.Edit_Type = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TabSheet_EPCC1G2 = new System.Windows.Forms.TabPage();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.maskLen_textBox = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.maskadr_textbox = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.CheckBox_EPCMaskEnabled = new System.Windows.Forms.CheckBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.Button_LockUserBlock_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode6 = new System.Windows.Forms.TextBox();
            this.ComboBox_BlockNum = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.ComboBox_EPC6 = new System.Windows.Forms.ComboBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.Label_Alarm = new System.Windows.Forms.Label();
            this.Button_CheckAlarm = new System.Windows.Forms.Button();
            this.Button_SetEASAlarm_G2 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.NoAlarm_G2 = new System.Windows.Forms.RadioButton();
            this.Alarm_G2 = new System.Windows.Forms.RadioButton();
            this.Edit_AccessCode5 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.ComboBox_EPC5 = new System.Windows.Forms.ComboBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.Button_CheckReadProtected_G2 = new System.Windows.Forms.Button();
            this.Button_RemoveReadProtect_G2 = new System.Windows.Forms.Button();
            this.Button_SetMultiReadProtect_G2 = new System.Windows.Forms.Button();
            this.Button_SetReadProtect_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode4 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.ComboBox_EPC4 = new System.Windows.Forms.ComboBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.Button_WriteEPC_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode3 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.Edit_WriteEPC = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.Button_DestroyCard = new System.Windows.Forms.Button();
            this.Edit_DestroyCode = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.ComboBox_EPC3 = new System.Windows.Forms.ComboBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.CheckBox_TID = new System.Windows.Forms.CheckBox();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.Button_QueryTag = new System.Windows.Forms.Button();
            this.ComboBox_IntervalTime = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Button_SetProtectState = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.AlwaysNot2 = new System.Windows.Forms.RadioButton();
            this.Always2 = new System.Windows.Forms.RadioButton();
            this.Proect2 = new System.Windows.Forms.RadioButton();
            this.NoProect2 = new System.Windows.Forms.RadioButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.P_User = new System.Windows.Forms.RadioButton();
            this.P_TID = new System.Windows.Forms.RadioButton();
            this.P_EPC = new System.Windows.Forms.RadioButton();
            this.P_Reserve = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.AlwaysNot = new System.Windows.Forms.RadioButton();
            this.Always = new System.Windows.Forms.RadioButton();
            this.Proect = new System.Windows.Forms.RadioButton();
            this.NoProect = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.AccessCode = new System.Windows.Forms.RadioButton();
            this.DestroyCode = new System.Windows.Forms.RadioButton();
            this.ComboBox_EPC1 = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox_pc = new System.Windows.Forms.TextBox();
            this.checkBox_pc = new System.Windows.Forms.CheckBox();
            this.BlockWrite = new System.Windows.Forms.Button();
            this.ComboBox_EPC2 = new System.Windows.Forms.ComboBox();
            this.button7 = new System.Windows.Forms.Button();
            this.Button_BlockErase = new System.Windows.Forms.Button();
            this.Button_DataWrite = new System.Windows.Forms.Button();
            this.SpeedButton_Read_G2 = new System.Windows.Forms.Button();
            this.Edit_WriteData = new System.Windows.Forms.TextBox();
            this.Edit_AccessCode2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Edit_WordPtr = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.C_User = new System.Windows.Forms.RadioButton();
            this.C_TID = new System.Windows.Forms.RadioButton();
            this.C_EPC = new System.Windows.Forms.RadioButton();
            this.C_Reserve = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ListView1_EPC = new System.Windows.Forms.ListView();
            this.listViewCol_Number = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewCol_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewCol_Length = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewCol_Times = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TabSheet_6B = new System.Windows.Forms.TabPage();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.Edit_WriteData_6B = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.Button_Clear = new System.Windows.Forms.Button();
            this.Button_Check = new System.Windows.Forms.Button();
            this.Button_PermanentWrite = new System.Windows.Forms.Button();
            this.SpeedButton_Write_6B = new System.Windows.Forms.Button();
            this.SpeedButton_Read_6B = new System.Windows.Forms.Button();
            this.Edit_Len_6B = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.Edit_StartAddress_6B = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.ComboBox_ID1_6B = new System.Windows.Forms.ComboBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.Edit_ConditionContent_6B = new System.Windows.Forms.TextBox();
            this.Edit_Query_StartAddress_6B = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.Greater_6B = new System.Windows.Forms.RadioButton();
            this.Less_6B = new System.Windows.Forms.RadioButton();
            this.Different_6B = new System.Windows.Forms.RadioButton();
            this.Same_6B = new System.Windows.Forms.RadioButton();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.SpeedButton_Query_6B = new System.Windows.Forms.Button();
            this.Bycondition_6B = new System.Windows.Forms.RadioButton();
            this.Byone_6B = new System.Windows.Forms.RadioButton();
            this.ComboBox_IntervalTime_6B = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.ListView_ID_6B = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Button_GetFreq = new System.Windows.Forms.Button();
            this.Button_SetFreq = new System.Windows.Forms.Button();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.Button_ClearFreq = new System.Windows.Forms.Button();
            this.Button_StopFreq = new System.Windows.Forms.Button();
            this.Button_StartFreq = new System.Windows.Forms.Button();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.LEDFlashButton = new System.Windows.Forms.Button();
            this.changeIpButton = new System.Windows.Forms.Button();
            this.configButton = new System.Windows.Forms.Button();
            this.specificSearchButton = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.ipList = new System.Windows.Forms.ListView();
            this.ipListNoColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ipListMacColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ipListIpColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ipListUsernameColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ipListDeviceNameColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.StatusBar1 = new System.Windows.Forms.StatusBar();
            this.TStatusPanel = new System.Windows.Forms.StatusBarPanel();
            this.Port = new System.Windows.Forms.StatusBarPanel();
            this.Manufacturername = new System.Windows.Forms.StatusBarPanel();
            this.Timer_Test_ = new System.Windows.Forms.Timer(this.components);
            this.Timer_G2_Read = new System.Windows.Forms.Timer(this.components);
            this.Timer_G2_Alarm = new System.Windows.Forms.Timer(this.components);
            this.Timer_Test_6B = new System.Windows.Forms.Timer(this.components);
            this.Timer_6B_Read = new System.Windows.Forms.Timer(this.components);
            this.Timer_6B_Write = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.TabSheet_CMD.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.groupBox34.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.TabSheet_EPCC1G2.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.TabSheet_6B.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.groupBox35.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TStatusPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Port)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manufacturername)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.TabSheet_CMD);
            this.tabControl1.Controls.Add(this.TabSheet_EPCC1G2);
            this.tabControl1.Controls.Add(this.TabSheet_6B);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(2, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(825, 704);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // TabSheet_CMD
            // 
            this.TabSheet_CMD.BackColor = System.Drawing.Color.Transparent;
            this.TabSheet_CMD.Controls.Add(this.groupBox37);
            this.TabSheet_CMD.Controls.Add(this.groupBox34);
            this.TabSheet_CMD.Controls.Add(this.Button_ClearListBox);
            this.TabSheet_CMD.Controls.Add(this.Button_GetListBox);
            this.TabSheet_CMD.Controls.Add(this.listBox3);
            this.TabSheet_CMD.Controls.Add(this.groupBox23);
            this.TabSheet_CMD.Controls.Add(this.groupBox3);
            this.TabSheet_CMD.Controls.Add(this.groupBox2);
            this.TabSheet_CMD.Location = new System.Drawing.Point(4, 22);
            this.TabSheet_CMD.Name = "TabSheet_CMD";
            this.TabSheet_CMD.Padding = new System.Windows.Forms.Padding(3);
            this.TabSheet_CMD.Size = new System.Drawing.Size(817, 678);
            this.TabSheet_CMD.TabIndex = 1;
            this.TabSheet_CMD.Text = "Reader Parameter";
            this.TabSheet_CMD.UseVisualStyleBackColor = true;
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.groupBox41);
            this.groupBox37.Controls.Add(this.GroupBox1);
            this.groupBox37.Controls.Add(this.radioButton21);
            this.groupBox37.Controls.Add(this.radioButton22);
            this.groupBox37.Location = new System.Drawing.Point(2, 7);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(143, 447);
            this.groupBox37.TabIndex = 48;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "Communication";
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.CloseNetPort);
            this.groupBox41.Controls.Add(this.OpenNetPort);
            this.groupBox41.Controls.Add(this.Edit_TCPIPAddr);
            this.groupBox41.Controls.Add(this.label63);
            this.groupBox41.Controls.Add(this.Edit_TCPIPIP);
            this.groupBox41.Controls.Add(this.label64);
            this.groupBox41.Controls.Add(this.Edit_TCPIPPort);
            this.groupBox41.Controls.Add(this.label65);
            this.groupBox41.Location = new System.Drawing.Point(5, 261);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Size = new System.Drawing.Size(133, 180);
            this.groupBox41.TabIndex = 51;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "TCPIP";
            // 
            // CloseNetPort
            // 
            this.CloseNetPort.Location = new System.Drawing.Point(9, 147);
            this.CloseNetPort.Name = "CloseNetPort";
            this.CloseNetPort.Size = new System.Drawing.Size(113, 25);
            this.CloseNetPort.TabIndex = 7;
            this.CloseNetPort.Text = "CloseNetPort";
            this.CloseNetPort.UseVisualStyleBackColor = true;
            this.CloseNetPort.Click += new System.EventHandler(this.CloseNetPort_Click);
            // 
            // OpenNetPort
            // 
            this.OpenNetPort.Location = new System.Drawing.Point(9, 114);
            this.OpenNetPort.Name = "OpenNetPort";
            this.OpenNetPort.Size = new System.Drawing.Size(113, 25);
            this.OpenNetPort.TabIndex = 6;
            this.OpenNetPort.Text = "OpenNetPort";
            this.OpenNetPort.UseVisualStyleBackColor = true;
            this.OpenNetPort.Click += new System.EventHandler(this.OpenNetPort_Click);
            // 
            // Edit_TCPIPAddr
            // 
            this.Edit_TCPIPAddr.Location = new System.Drawing.Point(43, 85);
            this.Edit_TCPIPAddr.Name = "Edit_TCPIPAddr";
            this.Edit_TCPIPAddr.Size = new System.Drawing.Size(79, 20);
            this.Edit_TCPIPAddr.TabIndex = 5;
            this.Edit_TCPIPAddr.Text = "FF";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(7, 94);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(35, 13);
            this.label63.TabIndex = 4;
            this.label63.Text = "Addr：";
            // 
            // Edit_TCPIPIP
            // 
            this.Edit_TCPIPIP.Location = new System.Drawing.Point(33, 47);
            this.Edit_TCPIPIP.Name = "Edit_TCPIPIP";
            this.Edit_TCPIPIP.Size = new System.Drawing.Size(89, 20);
            this.Edit_TCPIPIP.TabIndex = 3;
            this.Edit_TCPIPIP.Text = "192.168.1.192";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(7, 56);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(23, 13);
            this.label64.TabIndex = 2;
            this.label64.Text = "IP：";
            // 
            // Edit_TCPIPPort
            // 
            this.Edit_TCPIPPort.Location = new System.Drawing.Point(40, 17);
            this.Edit_TCPIPPort.Name = "Edit_TCPIPPort";
            this.Edit_TCPIPPort.Size = new System.Drawing.Size(82, 20);
            this.Edit_TCPIPPort.TabIndex = 1;
            this.Edit_TCPIPPort.Text = "6000";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(6, 27);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(29, 13);
            this.label65.TabIndex = 0;
            this.label65.Text = "Port:";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.ComboBox_baud2);
            this.GroupBox1.Controls.Add(this.label47);
            this.GroupBox1.Controls.Add(this.ComboBox_AlreadyOpenCOM);
            this.GroupBox1.Controls.Add(this.label3);
            this.GroupBox1.Controls.Add(this.ClosePort);
            this.GroupBox1.Controls.Add(this.OpenPort);
            this.GroupBox1.Controls.Add(this.Edit_CmdComAddr);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.ComboBox_COM);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Location = new System.Drawing.Point(5, 36);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(133, 222);
            this.GroupBox1.TabIndex = 46;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Communication";
            // 
            // ComboBox_baud2
            // 
            this.ComboBox_baud2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_baud2.FormattingEnabled = true;
            this.ComboBox_baud2.Items.AddRange(new object[] {
            "9600bps",
            "19200bps",
            "38400bps",
            "57600bps",
            "115200bps"});
            this.ComboBox_baud2.Location = new System.Drawing.Point(6, 119);
            this.ComboBox_baud2.Name = "ComboBox_baud2";
            this.ComboBox_baud2.Size = new System.Drawing.Size(122, 21);
            this.ComboBox_baud2.TabIndex = 12;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(7, 103);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(61, 13);
            this.label47.TabIndex = 9;
            this.label47.Text = "Baud Rate:";
            // 
            // ComboBox_AlreadyOpenCOM
            // 
            this.ComboBox_AlreadyOpenCOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_AlreadyOpenCOM.FormattingEnabled = true;
            this.ComboBox_AlreadyOpenCOM.Location = new System.Drawing.Point(6, 164);
            this.ComboBox_AlreadyOpenCOM.Name = "ComboBox_AlreadyOpenCOM";
            this.ComboBox_AlreadyOpenCOM.Size = new System.Drawing.Size(122, 21);
            this.ComboBox_AlreadyOpenCOM.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Opened COM Port:";
            // 
            // ClosePort
            // 
            this.ClosePort.Location = new System.Drawing.Point(6, 190);
            this.ClosePort.Name = "ClosePort";
            this.ClosePort.Size = new System.Drawing.Size(122, 25);
            this.ClosePort.TabIndex = 5;
            this.ClosePort.Text = "ClosePort";
            this.ClosePort.UseVisualStyleBackColor = true;
            this.ClosePort.Click += new System.EventHandler(this.ClosePort_Click);
            // 
            // OpenPort
            // 
            this.OpenPort.Location = new System.Drawing.Point(6, 72);
            this.OpenPort.Name = "OpenPort";
            this.OpenPort.Size = new System.Drawing.Size(122, 25);
            this.OpenPort.TabIndex = 4;
            this.OpenPort.Text = "Open COM Port";
            this.OpenPort.UseVisualStyleBackColor = true;
            this.OpenPort.Click += new System.EventHandler(this.OpenPort_Click);
            // 
            // Edit_CmdComAddr
            // 
            this.Edit_CmdComAddr.BackColor = System.Drawing.SystemColors.Window;
            this.Edit_CmdComAddr.Location = new System.Drawing.Point(92, 42);
            this.Edit_CmdComAddr.MaxLength = 2;
            this.Edit_CmdComAddr.Name = "Edit_CmdComAddr";
            this.Edit_CmdComAddr.Size = new System.Drawing.Size(36, 20);
            this.Edit_CmdComAddr.TabIndex = 3;
            this.Edit_CmdComAddr.Text = "FF";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(6, 46);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(86, 13);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Reader Address:";
            // 
            // ComboBox_COM
            // 
            this.ComboBox_COM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_COM.FormattingEnabled = true;
            this.ComboBox_COM.Location = new System.Drawing.Point(65, 14);
            this.ComboBox_COM.Name = "ComboBox_COM";
            this.ComboBox_COM.Size = new System.Drawing.Size(63, 21);
            this.ComboBox_COM.TabIndex = 1;
            this.ComboBox_COM.SelectedIndexChanged += new System.EventHandler(this.ComboBox_COM_SelectedIndexChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(5, 23);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(59, 13);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "COM Port：";
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(74, 16);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(56, 17);
            this.radioButton21.TabIndex = 45;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "TCPIP";
            this.radioButton21.UseVisualStyleBackColor = true;
            this.radioButton21.CheckedChanged += new System.EventHandler(this.radioButton21_CheckedChanged);
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(9, 16);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(49, 17);
            this.radioButton22.TabIndex = 44;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "COM";
            this.radioButton22.UseVisualStyleBackColor = true;
            this.radioButton22.CheckedChanged += new System.EventHandler(this.radioButton22_CheckedChanged);
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.label57);
            this.groupBox34.Controls.Add(this.label56);
            this.groupBox34.Controls.Add(this.ComboBox_Relay2);
            this.groupBox34.Controls.Add(this.Button_Relay);
            this.groupBox34.Controls.Add(this.ComboBox_Relay1);
            this.groupBox34.Location = new System.Drawing.Point(6, 456);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(136, 95);
            this.groupBox34.TabIndex = 47;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "Relay";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(90, 17);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(13, 13);
            this.label57.TabIndex = 4;
            this.label57.Text = "2";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(31, 17);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(13, 13);
            this.label56.TabIndex = 3;
            this.label56.Text = "1";
            // 
            // ComboBox_Relay2
            // 
            this.ComboBox_Relay2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_Relay2.FormattingEnabled = true;
            this.ComboBox_Relay2.Items.AddRange(new object[] {
            "Release",
            "Active"});
            this.ComboBox_Relay2.Location = new System.Drawing.Point(70, 34);
            this.ComboBox_Relay2.Name = "ComboBox_Relay2";
            this.ComboBox_Relay2.Size = new System.Drawing.Size(61, 21);
            this.ComboBox_Relay2.TabIndex = 2;
            // 
            // Button_Relay
            // 
            this.Button_Relay.Enabled = false;
            this.Button_Relay.Location = new System.Drawing.Point(7, 62);
            this.Button_Relay.Name = "Button_Relay";
            this.Button_Relay.Size = new System.Drawing.Size(120, 25);
            this.Button_Relay.TabIndex = 1;
            this.Button_Relay.Text = "Set";
            this.Button_Relay.UseVisualStyleBackColor = true;
            this.Button_Relay.Click += new System.EventHandler(this.button20_Click);
            // 
            // ComboBox_Relay1
            // 
            this.ComboBox_Relay1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_Relay1.FormattingEnabled = true;
            this.ComboBox_Relay1.Items.AddRange(new object[] {
            "Release",
            "Active"});
            this.ComboBox_Relay1.Location = new System.Drawing.Point(6, 34);
            this.ComboBox_Relay1.Name = "ComboBox_Relay1";
            this.ComboBox_Relay1.Size = new System.Drawing.Size(61, 21);
            this.ComboBox_Relay1.TabIndex = 0;
            // 
            // Button_ClearListBox
            // 
            this.Button_ClearListBox.Location = new System.Drawing.Point(685, 623);
            this.Button_ClearListBox.Name = "Button_ClearListBox";
            this.Button_ClearListBox.Size = new System.Drawing.Size(112, 25);
            this.Button_ClearListBox.TabIndex = 46;
            this.Button_ClearListBox.Text = "Clear";
            this.Button_ClearListBox.UseVisualStyleBackColor = true;
            this.Button_ClearListBox.Click += new System.EventHandler(this.Button_ClearListBox_Click);
            // 
            // Button_GetListBox
            // 
            this.Button_GetListBox.Location = new System.Drawing.Point(685, 579);
            this.Button_GetListBox.Name = "Button_GetListBox";
            this.Button_GetListBox.Size = new System.Drawing.Size(112, 25);
            this.Button_GetListBox.TabIndex = 45;
            this.Button_GetListBox.Text = "Get ";
            this.Button_GetListBox.UseVisualStyleBackColor = true;
            this.Button_GetListBox.Click += new System.EventHandler(this.Button_GetListBox_Click);
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(147, 560);
            this.listBox3.Name = "listBox3";
            this.listBox3.ScrollAlwaysVisible = true;
            this.listBox3.Size = new System.Drawing.Size(512, 108);
            this.listBox3.TabIndex = 44;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.groupBox26);
            this.groupBox23.Controls.Add(this.groupBox24);
            this.groupBox23.Location = new System.Drawing.Point(147, 268);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(663, 286);
            this.groupBox23.TabIndex = 43;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Work Mode Parameter";
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.button_gettigtime);
            this.groupBox26.Controls.Add(this.button_settigtime);
            this.groupBox26.Controls.Add(this.comboBox_tigtime);
            this.groupBox26.Controls.Add(this.label53);
            this.groupBox26.Controls.Add(this.button_OffsetTime);
            this.groupBox26.Controls.Add(this.comboBox_OffsetTime);
            this.groupBox26.Controls.Add(this.label48);
            this.groupBox26.Controls.Add(this.Button_SetAccuracy);
            this.groupBox26.Controls.Add(this.ComboBox_EASAccuracy);
            this.groupBox26.Controls.Add(this.label46);
            this.groupBox26.Controls.Add(this.button9);
            this.groupBox26.Controls.Add(this.comboBox6);
            this.groupBox26.Controls.Add(this.label45);
            this.groupBox26.Controls.Add(this.groupBox32);
            this.groupBox26.Controls.Add(this.textBox3);
            this.groupBox26.Controls.Add(this.Button_SetWorkMode);
            this.groupBox26.Controls.Add(this.comboBox5);
            this.groupBox26.Controls.Add(this.label42);
            this.groupBox26.Controls.Add(this.label41);
            this.groupBox26.Controls.Add(this.comboBox4);
            this.groupBox26.Controls.Add(this.label40);
            this.groupBox26.Controls.Add(this.groupBox29);
            this.groupBox26.Controls.Add(this.groupBox28);
            this.groupBox26.Controls.Add(this.groupBox27);
            this.groupBox26.Controls.Add(this.radioButton6);
            this.groupBox26.Controls.Add(this.radioButton5);
            this.groupBox26.Location = new System.Drawing.Point(8, 99);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(649, 181);
            this.groupBox26.TabIndex = 1;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Set Work Mode";
            // 
            // button_gettigtime
            // 
            this.button_gettigtime.Enabled = false;
            this.button_gettigtime.Location = new System.Drawing.Point(258, 148);
            this.button_gettigtime.Name = "button_gettigtime";
            this.button_gettigtime.Size = new System.Drawing.Size(106, 25);
            this.button_gettigtime.TabIndex = 69;
            this.button_gettigtime.Text = "Get TiggerTime";
            this.button_gettigtime.UseVisualStyleBackColor = true;
            this.button_gettigtime.Click += new System.EventHandler(this.button_gettigtime_Click);
            // 
            // button_settigtime
            // 
            this.button_settigtime.Enabled = false;
            this.button_settigtime.Location = new System.Drawing.Point(149, 148);
            this.button_settigtime.Name = "button_settigtime";
            this.button_settigtime.Size = new System.Drawing.Size(106, 25);
            this.button_settigtime.TabIndex = 68;
            this.button_settigtime.Text = "Set TiggerTime";
            this.button_settigtime.UseVisualStyleBackColor = true;
            this.button_settigtime.Click += new System.EventHandler(this.button_settigtime_Click);
            // 
            // comboBox_tigtime
            // 
            this.comboBox_tigtime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_tigtime.FormattingEnabled = true;
            this.comboBox_tigtime.Location = new System.Drawing.Point(93, 151);
            this.comboBox_tigtime.Name = "comboBox_tigtime";
            this.comboBox_tigtime.Size = new System.Drawing.Size(52, 21);
            this.comboBox_tigtime.TabIndex = 67;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(6, 157);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(66, 13);
            this.label53.TabIndex = 66;
            this.label53.Text = "Tigger Time:";
            // 
            // button_OffsetTime
            // 
            this.button_OffsetTime.Enabled = false;
            this.button_OffsetTime.Location = new System.Drawing.Point(391, 116);
            this.button_OffsetTime.Name = "button_OffsetTime";
            this.button_OffsetTime.Size = new System.Drawing.Size(91, 25);
            this.button_OffsetTime.TabIndex = 58;
            this.button_OffsetTime.Text = "SetOffsetTime";
            this.button_OffsetTime.UseVisualStyleBackColor = true;
            this.button_OffsetTime.Click += new System.EventHandler(this.button_OffsetTime_Click);
            // 
            // comboBox_OffsetTime
            // 
            this.comboBox_OffsetTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_OffsetTime.FormattingEnabled = true;
            this.comboBox_OffsetTime.Location = new System.Drawing.Point(318, 117);
            this.comboBox_OffsetTime.Name = "comboBox_OffsetTime";
            this.comboBox_OffsetTime.Size = new System.Drawing.Size(68, 21);
            this.comboBox_OffsetTime.TabIndex = 57;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(247, 122);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(61, 13);
            this.label48.TabIndex = 56;
            this.label48.Text = "OffsetTime:";
            // 
            // Button_SetAccuracy
            // 
            this.Button_SetAccuracy.Enabled = false;
            this.Button_SetAccuracy.Location = new System.Drawing.Point(153, 117);
            this.Button_SetAccuracy.Name = "Button_SetAccuracy";
            this.Button_SetAccuracy.Size = new System.Drawing.Size(81, 25);
            this.Button_SetAccuracy.TabIndex = 55;
            this.Button_SetAccuracy.Text = "SetAccuracy";
            this.Button_SetAccuracy.UseVisualStyleBackColor = true;
            this.Button_SetAccuracy.Click += new System.EventHandler(this.Button_SetAccuracy_Click);
            // 
            // ComboBox_EASAccuracy
            // 
            this.ComboBox_EASAccuracy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EASAccuracy.FormattingEnabled = true;
            this.ComboBox_EASAccuracy.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.ComboBox_EASAccuracy.Location = new System.Drawing.Point(93, 118);
            this.ComboBox_EASAccuracy.Name = "ComboBox_EASAccuracy";
            this.ComboBox_EASAccuracy.Size = new System.Drawing.Size(55, 21);
            this.ComboBox_EASAccuracy.TabIndex = 54;
            this.ComboBox_EASAccuracy.SelectedIndexChanged += new System.EventHandler(this.ComboBox_EASAccuracy_SelectedIndexChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(9, 124);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(79, 13);
            this.label46.TabIndex = 53;
            this.label46.Text = "EAS Accuracy:";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(490, 116);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(152, 25);
            this.button9.TabIndex = 52;
            this.button9.Text = "Get Work Mode parameter";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // comboBox6
            // 
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(595, 39);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(48, 21);
            this.comboBox6.TabIndex = 51;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(434, 47);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(126, 13);
            this.label45.TabIndex = 50;
            this.label45.Text = "Single Tag Filtering Time:";
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.radioButton17);
            this.groupBox32.Controls.Add(this.radioButton16);
            this.groupBox32.Location = new System.Drawing.Point(173, 69);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(126, 46);
            this.groupBox32.TabIndex = 49;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "First Addr Select";
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(9, 27);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(71, 17);
            this.radioButton17.TabIndex = 1;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "Byte Addr";
            this.radioButton17.UseVisualStyleBackColor = true;
            this.radioButton17.CheckedChanged += new System.EventHandler(this.radioButton17_CheckedChanged);
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(9, 13);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(76, 17);
            this.radioButton16.TabIndex = 0;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "Word Addr";
            this.radioButton16.UseVisualStyleBackColor = true;
            this.radioButton16.CheckedChanged += new System.EventHandler(this.radioButton16_CheckedChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(560, 66);
            this.textBox3.MaxLength = 2;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(30, 20);
            this.textBox3.TabIndex = 47;
            this.textBox3.Text = "02";
            this.textBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // Button_SetWorkMode
            // 
            this.Button_SetWorkMode.Location = new System.Drawing.Point(595, 69);
            this.Button_SetWorkMode.Name = "Button_SetWorkMode";
            this.Button_SetWorkMode.Size = new System.Drawing.Size(48, 42);
            this.Button_SetWorkMode.TabIndex = 11;
            this.Button_SetWorkMode.Text = "Set";
            this.Button_SetWorkMode.UseVisualStyleBackColor = true;
            this.Button_SetWorkMode.Click += new System.EventHandler(this.Button_SetWorkMode_Click);
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(539, 91);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(51, 21);
            this.comboBox5.TabIndex = 9;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(432, 98);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(105, 13);
            this.label42.TabIndex = 8;
            this.label42.Text = "Read Word Number:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(430, 73);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(108, 13);
            this.label41.TabIndex = 7;
            this.label41.Text = "First Word Addr(Hex):";
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Answer Mode",
            "Active mode",
            "Trigger mode(Low)",
            "Trigger mode(High)"});
            this.comboBox4.Location = new System.Drawing.Point(511, 14);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(132, 21);
            this.comboBox4.TabIndex = 6;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(441, 22);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(66, 13);
            this.label40.TabIndex = 5;
            this.label40.Text = "Work Mode:";
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.radioButton15);
            this.groupBox29.Controls.Add(this.radioButton14);
            this.groupBox29.Location = new System.Drawing.Point(303, 69);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(127, 44);
            this.groupBox29.TabIndex = 4;
            this.groupBox29.TabStop = false;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(6, 24);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(107, 17);
            this.radioButton15.TabIndex = 1;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "DisEnable buzzer";
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(6, 8);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(98, 17);
            this.radioButton14.TabIndex = 0;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "Activate buzzer";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.radioButton19);
            this.groupBox28.Controls.Add(this.radioButton18);
            this.groupBox28.Controls.Add(this.radioButton13);
            this.groupBox28.Controls.Add(this.radioButton12);
            this.groupBox28.Controls.Add(this.radioButton11);
            this.groupBox28.Controls.Add(this.radioButton10);
            this.groupBox28.Controls.Add(this.radioButton9);
            this.groupBox28.Location = new System.Drawing.Point(173, 9);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(257, 61);
            this.groupBox28.TabIndex = 3;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Storage area or inquiry conducted Tags";
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(179, 41);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(46, 17);
            this.radioButton19.TabIndex = 6;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "EAS";
            this.radioButton19.UseVisualStyleBackColor = true;
            this.radioButton19.CheckedChanged += new System.EventHandler(this.radioButton19_CheckedChanged);
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(97, 41);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(76, 17);
            this.radioButton18.TabIndex = 5;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "Single-Tag";
            this.radioButton18.UseVisualStyleBackColor = true;
            this.radioButton18.CheckedChanged += new System.EventHandler(this.radioButton18_CheckedChanged);
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(9, 41);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(69, 17);
            this.radioButton13.TabIndex = 4;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Multi-Tag";
            this.radioButton13.UseVisualStyleBackColor = true;
            this.radioButton13.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(178, 17);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(47, 17);
            this.radioButton12.TabIndex = 3;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "User";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(131, 17);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(43, 17);
            this.radioButton11.TabIndex = 2;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "TID";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(81, 17);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(46, 17);
            this.radioButton10.TabIndex = 1;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "EPC";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(7, 17);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(71, 17);
            this.radioButton9.TabIndex = 0;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "Password";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.radioButton20);
            this.groupBox27.Controls.Add(this.radioButton8);
            this.groupBox27.Controls.Add(this.radioButton7);
            this.groupBox27.Location = new System.Drawing.Point(11, 37);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(155, 75);
            this.groupBox27.TabIndex = 2;
            this.groupBox27.TabStop = false;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Enabled = false;
            this.radioButton20.Location = new System.Drawing.Point(6, 50);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(110, 17);
            this.radioButton20.TabIndex = 3;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "SYRIS485 Output";
            this.radioButton20.UseVisualStyleBackColor = true;
            this.radioButton20.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(6, 30);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(131, 17);
            this.radioButton8.TabIndex = 1;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "RS232/RS485 Output";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(6, 11);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(103, 17);
            this.radioButton7.TabIndex = 0;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Wiegand Output";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(83, 21);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(89, 17);
            this.radioButton6.TabIndex = 1;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "ISO18000-6B";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(11, 21);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(76, 17);
            this.radioButton5.TabIndex = 0;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "EPCC1-G2";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.Button_SetWGParameter);
            this.groupBox24.Controls.Add(this.comboBox3);
            this.groupBox24.Controls.Add(this.label39);
            this.groupBox24.Controls.Add(this.comboBox2);
            this.groupBox24.Controls.Add(this.comboBox1);
            this.groupBox24.Controls.Add(this.label38);
            this.groupBox24.Controls.Add(this.label37);
            this.groupBox24.Controls.Add(this.groupBox25);
            this.groupBox24.Controls.Add(this.radioButton2);
            this.groupBox24.Controls.Add(this.radioButton1);
            this.groupBox24.Location = new System.Drawing.Point(8, 13);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(649, 83);
            this.groupBox24.TabIndex = 0;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Wiegand Parameter";
            // 
            // Button_SetWGParameter
            // 
            this.Button_SetWGParameter.Location = new System.Drawing.Point(437, 52);
            this.Button_SetWGParameter.Name = "Button_SetWGParameter";
            this.Button_SetWGParameter.Size = new System.Drawing.Size(206, 25);
            this.Button_SetWGParameter.TabIndex = 9;
            this.Button_SetWGParameter.Text = "SetWGParameter";
            this.Button_SetWGParameter.UseVisualStyleBackColor = true;
            this.Button_SetWGParameter.Click += new System.EventHandler(this.Button_SetWGParameter_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(510, 14);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(132, 21);
            this.comboBox3.TabIndex = 8;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(440, 17);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(64, 13);
            this.label39.TabIndex = 7;
            this.label39.Text = "Pulse width:";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(318, 56);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(109, 21);
            this.comboBox2.TabIndex = 6;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(318, 14);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(109, 21);
            this.comboBox1.TabIndex = 5;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(247, 60);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(73, 13);
            this.label38.TabIndex = 4;
            this.label38.Text = "Pulse interval:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(217, 17);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(103, 13);
            this.label37.TabIndex = 3;
            this.label37.Text = "Data output interval:";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.radioButton4);
            this.groupBox25.Controls.Add(this.radioButton3);
            this.groupBox25.Location = new System.Drawing.Point(11, 33);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(174, 45);
            this.groupBox25.TabIndex = 2;
            this.groupBox25.TabStop = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(6, 25);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(146, 17);
            this.radioButton4.TabIndex = 1;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Wiegand output MSB first";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(6, 8);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(143, 17);
            this.radioButton3.TabIndex = 0;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Wiegand output LSB first";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(105, 16);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(80, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Wiegand34";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(11, 16);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(80, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Wiegand26";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox30);
            this.groupBox3.Controls.Add(this.progressBar1);
            this.groupBox3.Controls.Add(this.Button_DefaultParameter);
            this.groupBox3.Controls.Add(this.Button_SetParameter);
            this.groupBox3.Controls.Add(this.ComboBox_scantime);
            this.groupBox3.Controls.Add(this.ComboBox_baud);
            this.groupBox3.Controls.Add(this.CheckBox_SameFre);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.ComboBox_dmaxfre);
            this.groupBox3.Controls.Add(this.ComboBox_dminfre);
            this.groupBox3.Controls.Add(this.ComboBox_PowerDbm);
            this.groupBox3.Controls.Add(this.Edit_NewComAdr);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Location = new System.Drawing.Point(147, 120);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(663, 145);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Set Reader Parameter";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.radioButton_band5);
            this.groupBox30.Controls.Add(this.radioButton_band4);
            this.groupBox30.Controls.Add(this.radioButton_band3);
            this.groupBox30.Controls.Add(this.radioButton_band2);
            this.groupBox30.Controls.Add(this.radioButton_band1);
            this.groupBox30.Location = new System.Drawing.Point(475, 10);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(180, 99);
            this.groupBox30.TabIndex = 44;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "FreqBand Setting";
            // 
            // radioButton_band5
            // 
            this.radioButton_band5.AutoSize = true;
            this.radioButton_band5.Location = new System.Drawing.Point(6, 79);
            this.radioButton_band5.Name = "radioButton_band5";
            this.radioButton_band5.Size = new System.Drawing.Size(67, 17);
            this.radioButton_band5.TabIndex = 5;
            this.radioButton_band5.TabStop = true;
            this.radioButton_band5.Text = "EU band";
            this.radioButton_band5.UseVisualStyleBackColor = true;
            this.radioButton_band5.CheckedChanged += new System.EventHandler(this.radioButton_band5_CheckedChanged);
            // 
            // radioButton_band4
            // 
            this.radioButton_band4.AutoSize = true;
            this.radioButton_band4.Location = new System.Drawing.Point(6, 62);
            this.radioButton_band4.Name = "radioButton_band4";
            this.radioButton_band4.Size = new System.Drawing.Size(86, 17);
            this.radioButton_band4.TabIndex = 3;
            this.radioButton_band4.TabStop = true;
            this.radioButton_band4.Text = "Korean band";
            this.radioButton_band4.UseVisualStyleBackColor = true;
            this.radioButton_band4.CheckedChanged += new System.EventHandler(this.radioButton_band4_CheckedChanged);
            // 
            // radioButton_band3
            // 
            this.radioButton_band3.AutoSize = true;
            this.radioButton_band3.Location = new System.Drawing.Point(6, 47);
            this.radioButton_band3.Name = "radioButton_band3";
            this.radioButton_band3.Size = new System.Drawing.Size(67, 17);
            this.radioButton_band3.TabIndex = 2;
            this.radioButton_band3.TabStop = true;
            this.radioButton_band3.Text = "US band";
            this.radioButton_band3.UseVisualStyleBackColor = true;
            this.radioButton_band3.CheckedChanged += new System.EventHandler(this.radioButton_band3_CheckedChanged);
            // 
            // radioButton_band2
            // 
            this.radioButton_band2.AutoSize = true;
            this.radioButton_band2.Location = new System.Drawing.Point(6, 30);
            this.radioButton_band2.Name = "radioButton_band2";
            this.radioButton_band2.Size = new System.Drawing.Size(96, 17);
            this.radioButton_band2.TabIndex = 1;
            this.radioButton_band2.TabStop = true;
            this.radioButton_band2.Text = "Chinese band2";
            this.radioButton_band2.UseVisualStyleBackColor = true;
            this.radioButton_band2.CheckedChanged += new System.EventHandler(this.radioButton_band2_CheckedChanged);
            // 
            // radioButton_band1
            // 
            this.radioButton_band1.AutoSize = true;
            this.radioButton_band1.Location = new System.Drawing.Point(6, 14);
            this.radioButton_band1.Name = "radioButton_band1";
            this.radioButton_band1.Size = new System.Drawing.Size(74, 17);
            this.radioButton_band1.TabIndex = 0;
            this.radioButton_band1.TabStop = true;
            this.radioButton_band1.Text = "User band";
            this.radioButton_band1.UseVisualStyleBackColor = true;
            this.radioButton_band1.CheckedChanged += new System.EventHandler(this.radioButton_band1_CheckedChanged);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(126, 95);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(399, 25);
            this.progressBar1.TabIndex = 43;
            // 
            // Button_DefaultParameter
            // 
            this.Button_DefaultParameter.Location = new System.Drawing.Point(538, 113);
            this.Button_DefaultParameter.Name = "Button_DefaultParameter";
            this.Button_DefaultParameter.Size = new System.Drawing.Size(118, 25);
            this.Button_DefaultParameter.TabIndex = 14;
            this.Button_DefaultParameter.Text = "Default Parameter";
            this.Button_DefaultParameter.UseVisualStyleBackColor = true;
            this.Button_DefaultParameter.Click += new System.EventHandler(this.Button_DefaultParameter_Click);
            // 
            // Button_SetParameter
            // 
            this.Button_SetParameter.Location = new System.Drawing.Point(404, 113);
            this.Button_SetParameter.Name = "Button_SetParameter";
            this.Button_SetParameter.Size = new System.Drawing.Size(121, 25);
            this.Button_SetParameter.TabIndex = 13;
            this.Button_SetParameter.Text = "Set Parameter";
            this.Button_SetParameter.UseVisualStyleBackColor = true;
            this.Button_SetParameter.Click += new System.EventHandler(this.Button_SetParameter_Click);
            // 
            // ComboBox_scantime
            // 
            this.ComboBox_scantime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_scantime.FormattingEnabled = true;
            this.ComboBox_scantime.Location = new System.Drawing.Point(348, 49);
            this.ComboBox_scantime.Name = "ComboBox_scantime";
            this.ComboBox_scantime.Size = new System.Drawing.Size(121, 21);
            this.ComboBox_scantime.TabIndex = 12;
            // 
            // ComboBox_baud
            // 
            this.ComboBox_baud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_baud.FormattingEnabled = true;
            this.ComboBox_baud.Items.AddRange(new object[] {
            "9600bps",
            "19200bps",
            "38400bps",
            "57600bps",
            "115200bps"});
            this.ComboBox_baud.Location = new System.Drawing.Point(348, 16);
            this.ComboBox_baud.Name = "ComboBox_baud";
            this.ComboBox_baud.Size = new System.Drawing.Size(121, 21);
            this.ComboBox_baud.TabIndex = 11;
            // 
            // CheckBox_SameFre
            // 
            this.CheckBox_SameFre.AutoSize = true;
            this.CheckBox_SameFre.Location = new System.Drawing.Point(215, 81);
            this.CheckBox_SameFre.Name = "CheckBox_SameFre";
            this.CheckBox_SameFre.Size = new System.Drawing.Size(138, 17);
            this.CheckBox_SameFre.TabIndex = 10;
            this.CheckBox_SameFre.Text = "Single Frequency Point ";
            this.CheckBox_SameFre.UseVisualStyleBackColor = true;
            this.CheckBox_SameFre.CheckedChanged += new System.EventHandler(this.CheckBox_SameFre_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(213, 52);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(125, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "Max InventoryScanTime:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(213, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "Baud Rate:";
            // 
            // ComboBox_dmaxfre
            // 
            this.ComboBox_dmaxfre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_dmaxfre.FormattingEnabled = true;
            this.ComboBox_dmaxfre.Location = new System.Drawing.Point(95, 115);
            this.ComboBox_dmaxfre.Name = "ComboBox_dmaxfre";
            this.ComboBox_dmaxfre.Size = new System.Drawing.Size(100, 21);
            this.ComboBox_dmaxfre.TabIndex = 7;
            this.ComboBox_dmaxfre.SelectedIndexChanged += new System.EventHandler(this.ComboBox_dfreSelect);
            // 
            // ComboBox_dminfre
            // 
            this.ComboBox_dminfre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_dminfre.FormattingEnabled = true;
            this.ComboBox_dminfre.Location = new System.Drawing.Point(95, 79);
            this.ComboBox_dminfre.Name = "ComboBox_dminfre";
            this.ComboBox_dminfre.Size = new System.Drawing.Size(100, 21);
            this.ComboBox_dminfre.TabIndex = 6;
            this.ComboBox_dminfre.SelectedIndexChanged += new System.EventHandler(this.ComboBox_dfreSelect);
            // 
            // ComboBox_PowerDbm
            // 
            this.ComboBox_PowerDbm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_PowerDbm.FormattingEnabled = true;
            this.ComboBox_PowerDbm.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.ComboBox_PowerDbm.Location = new System.Drawing.Point(95, 49);
            this.ComboBox_PowerDbm.Name = "ComboBox_PowerDbm";
            this.ComboBox_PowerDbm.Size = new System.Drawing.Size(100, 21);
            this.ComboBox_PowerDbm.TabIndex = 5;
            // 
            // Edit_NewComAdr
            // 
            this.Edit_NewComAdr.Location = new System.Drawing.Point(95, 16);
            this.Edit_NewComAdr.MaxLength = 2;
            this.Edit_NewComAdr.Name = "Edit_NewComAdr";
            this.Edit_NewComAdr.Size = new System.Drawing.Size(100, 20);
            this.Edit_NewComAdr.TabIndex = 4;
            this.Edit_NewComAdr.Text = "00";
            this.Edit_NewComAdr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 118);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Max.Frequency:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 82);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Min.Frequency:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 52);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Power:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Address(HEX):";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Button_GetReaderInfo);
            this.groupBox2.Controls.Add(this.Edit_scantime);
            this.groupBox2.Controls.Add(this.EPCC1G2);
            this.groupBox2.Controls.Add(this.ISO180006B);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.ProtocolLabel);
            this.groupBox2.Controls.Add(this.Edit_dmaxfre);
            this.groupBox2.Controls.Add(this.Edit_powerdBm);
            this.groupBox2.Controls.Add(this.Edit_Version);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.Edit_dminfre);
            this.groupBox2.Controls.Add(this.Edit_ComAdr);
            this.groupBox2.Controls.Add(this.Edit_Type);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(147, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(663, 113);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reader Information";
            // 
            // Button_GetReaderInfo
            // 
            this.Button_GetReaderInfo.Location = new System.Drawing.Point(538, 82);
            this.Button_GetReaderInfo.Name = "Button_GetReaderInfo";
            this.Button_GetReaderInfo.Size = new System.Drawing.Size(118, 25);
            this.Button_GetReaderInfo.TabIndex = 17;
            this.Button_GetReaderInfo.Text = "Get Reader Info";
            this.Button_GetReaderInfo.UseVisualStyleBackColor = true;
            this.Button_GetReaderInfo.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Edit_scantime
            // 
            this.Edit_scantime.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_scantime.Location = new System.Drawing.Point(538, 52);
            this.Edit_scantime.Name = "Edit_scantime";
            this.Edit_scantime.Size = new System.Drawing.Size(118, 20);
            this.Edit_scantime.TabIndex = 16;
            // 
            // EPCC1G2
            // 
            this.EPCC1G2.AutoSize = true;
            this.EPCC1G2.Location = new System.Drawing.Point(538, 33);
            this.EPCC1G2.Name = "EPCC1G2";
            this.EPCC1G2.Size = new System.Drawing.Size(77, 17);
            this.EPCC1G2.TabIndex = 15;
            this.EPCC1G2.Text = "EPCC1-G2";
            this.EPCC1G2.UseVisualStyleBackColor = true;
            // 
            // ISO180006B
            // 
            this.ISO180006B.AutoSize = true;
            this.ISO180006B.Location = new System.Drawing.Point(538, 12);
            this.ISO180006B.Name = "ISO180006B";
            this.ISO180006B.Size = new System.Drawing.Size(90, 17);
            this.ISO180006B.TabIndex = 14;
            this.ISO180006B.Text = "ISO18000-6B";
            this.ISO180006B.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(402, 56);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 13);
            this.label11.TabIndex = 13;
            this.label11.Text = "Max InventoryScanTime:";
            // 
            // ProtocolLabel
            // 
            this.ProtocolLabel.AutoSize = true;
            this.ProtocolLabel.Location = new System.Drawing.Point(402, 21);
            this.ProtocolLabel.Name = "ProtocolLabel";
            this.ProtocolLabel.Size = new System.Drawing.Size(49, 13);
            this.ProtocolLabel.TabIndex = 12;
            this.ProtocolLabel.Text = "Protocol:";
            // 
            // Edit_dmaxfre
            // 
            this.Edit_dmaxfre.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_dmaxfre.Location = new System.Drawing.Point(286, 85);
            this.Edit_dmaxfre.Name = "Edit_dmaxfre";
            this.Edit_dmaxfre.Size = new System.Drawing.Size(100, 20);
            this.Edit_dmaxfre.TabIndex = 11;
            // 
            // Edit_powerdBm
            // 
            this.Edit_powerdBm.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_powerdBm.Location = new System.Drawing.Point(286, 53);
            this.Edit_powerdBm.Name = "Edit_powerdBm";
            this.Edit_powerdBm.Size = new System.Drawing.Size(100, 20);
            this.Edit_powerdBm.TabIndex = 10;
            // 
            // Edit_Version
            // 
            this.Edit_Version.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_Version.Location = new System.Drawing.Point(286, 17);
            this.Edit_Version.Name = "Edit_Version";
            this.Edit_Version.Size = new System.Drawing.Size(100, 20);
            this.Edit_Version.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(197, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Max.Frequency:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Power:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(197, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Version:";
            // 
            // Edit_dminfre
            // 
            this.Edit_dminfre.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_dminfre.Location = new System.Drawing.Point(95, 85);
            this.Edit_dminfre.Name = "Edit_dminfre";
            this.Edit_dminfre.Size = new System.Drawing.Size(85, 20);
            this.Edit_dminfre.TabIndex = 5;
            // 
            // Edit_ComAdr
            // 
            this.Edit_ComAdr.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_ComAdr.Location = new System.Drawing.Point(95, 53);
            this.Edit_ComAdr.Name = "Edit_ComAdr";
            this.Edit_ComAdr.Size = new System.Drawing.Size(85, 20);
            this.Edit_ComAdr.TabIndex = 4;
            // 
            // Edit_Type
            // 
            this.Edit_Type.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_Type.Location = new System.Drawing.Point(95, 17);
            this.Edit_Type.Name = "Edit_Type";
            this.Edit_Type.Size = new System.Drawing.Size(85, 20);
            this.Edit_Type.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Min.Frequency:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Type:";
            // 
            // TabSheet_EPCC1G2
            // 
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox31);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox18);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox16);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox15);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox14);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox13);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox12);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox7);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox5);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox4);
            this.TabSheet_EPCC1G2.Location = new System.Drawing.Point(4, 22);
            this.TabSheet_EPCC1G2.Name = "TabSheet_EPCC1G2";
            this.TabSheet_EPCC1G2.Size = new System.Drawing.Size(817, 678);
            this.TabSheet_EPCC1G2.TabIndex = 2;
            this.TabSheet_EPCC1G2.Text = "EPCC1-G2 Test";
            this.TabSheet_EPCC1G2.UseVisualStyleBackColor = true;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.maskLen_textBox);
            this.groupBox31.Controls.Add(this.label44);
            this.groupBox31.Controls.Add(this.maskadr_textbox);
            this.groupBox31.Controls.Add(this.label43);
            this.groupBox31.Controls.Add(this.CheckBox_EPCMaskEnabled);
            this.groupBox31.Location = new System.Drawing.Point(2, 176);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(479, 52);
            this.groupBox31.TabIndex = 9;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "EPC Mask Enabled";
            // 
            // maskLen_textBox
            // 
            this.maskLen_textBox.Enabled = false;
            this.maskLen_textBox.Location = new System.Drawing.Point(345, 20);
            this.maskLen_textBox.MaxLength = 2;
            this.maskLen_textBox.Name = "maskLen_textBox";
            this.maskLen_textBox.Size = new System.Drawing.Size(122, 20);
            this.maskLen_textBox.TabIndex = 4;
            this.maskLen_textBox.Text = "00";
            this.maskLen_textBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(286, 25);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(54, 13);
            this.label44.TabIndex = 3;
            this.label44.Text = "MaskLen:";
            // 
            // maskadr_textbox
            // 
            this.maskadr_textbox.Enabled = false;
            this.maskadr_textbox.Location = new System.Drawing.Point(168, 20);
            this.maskadr_textbox.MaxLength = 2;
            this.maskadr_textbox.Name = "maskadr_textbox";
            this.maskadr_textbox.Size = new System.Drawing.Size(100, 20);
            this.maskadr_textbox.TabIndex = 2;
            this.maskadr_textbox.Text = "00";
            this.maskadr_textbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(109, 25);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 13);
            this.label43.TabIndex = 1;
            this.label43.Text = "MaskAdr:";
            // 
            // CheckBox_EPCMaskEnabled
            // 
            this.CheckBox_EPCMaskEnabled.AutoSize = true;
            this.CheckBox_EPCMaskEnabled.Enabled = false;
            this.CheckBox_EPCMaskEnabled.Location = new System.Drawing.Point(4, 24);
            this.CheckBox_EPCMaskEnabled.Name = "CheckBox_EPCMaskEnabled";
            this.CheckBox_EPCMaskEnabled.Size = new System.Drawing.Size(65, 17);
            this.CheckBox_EPCMaskEnabled.TabIndex = 0;
            this.CheckBox_EPCMaskEnabled.Text = "Enabled";
            this.CheckBox_EPCMaskEnabled.UseVisualStyleBackColor = true;
            this.CheckBox_EPCMaskEnabled.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.Button_LockUserBlock_G2);
            this.groupBox18.Controls.Add(this.Edit_AccessCode6);
            this.groupBox18.Controls.Add(this.ComboBox_BlockNum);
            this.groupBox18.Controls.Add(this.label30);
            this.groupBox18.Controls.Add(this.label29);
            this.groupBox18.Controls.Add(this.ComboBox_EPC6);
            this.groupBox18.Location = new System.Drawing.Point(485, 576);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(325, 99);
            this.groupBox18.TabIndex = 8;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Lock Block for User (Permanently Lock)";
            // 
            // Button_LockUserBlock_G2
            // 
            this.Button_LockUserBlock_G2.Location = new System.Drawing.Point(226, 68);
            this.Button_LockUserBlock_G2.Name = "Button_LockUserBlock_G2";
            this.Button_LockUserBlock_G2.Size = new System.Drawing.Size(89, 25);
            this.Button_LockUserBlock_G2.TabIndex = 5;
            this.Button_LockUserBlock_G2.Text = "Lock";
            this.Button_LockUserBlock_G2.UseVisualStyleBackColor = true;
            this.Button_LockUserBlock_G2.Click += new System.EventHandler(this.Button_LockUserBlock_G2_Click);
            // 
            // Edit_AccessCode6
            // 
            this.Edit_AccessCode6.Location = new System.Drawing.Point(134, 72);
            this.Edit_AccessCode6.MaxLength = 8;
            this.Edit_AccessCode6.Name = "Edit_AccessCode6";
            this.Edit_AccessCode6.Size = new System.Drawing.Size(85, 20);
            this.Edit_AccessCode6.TabIndex = 4;
            this.Edit_AccessCode6.Text = "00000000";
            this.Edit_AccessCode6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // ComboBox_BlockNum
            // 
            this.ComboBox_BlockNum.FormattingEnabled = true;
            this.ComboBox_BlockNum.Location = new System.Drawing.Point(134, 42);
            this.ComboBox_BlockNum.Name = "ComboBox_BlockNum";
            this.ComboBox_BlockNum.Size = new System.Drawing.Size(87, 21);
            this.ComboBox_BlockNum.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(9, 67);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(91, 26);
            this.label30.TabIndex = 2;
            this.label30.Text = "Access Password\r\n(8 Hex):";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(9, 39);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 26);
            this.label29.TabIndex = 1;
            this.label29.Text = "Address of Tag Data\r\n(Word):";
            // 
            // ComboBox_EPC6
            // 
            this.ComboBox_EPC6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC6.FormattingEnabled = true;
            this.ComboBox_EPC6.Location = new System.Drawing.Point(6, 15);
            this.ComboBox_EPC6.Name = "ComboBox_EPC6";
            this.ComboBox_EPC6.Size = new System.Drawing.Size(313, 21);
            this.ComboBox_EPC6.TabIndex = 0;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.Label_Alarm);
            this.groupBox16.Controls.Add(this.Button_CheckAlarm);
            this.groupBox16.Controls.Add(this.Button_SetEASAlarm_G2);
            this.groupBox16.Controls.Add(this.groupBox17);
            this.groupBox16.Controls.Add(this.Edit_AccessCode5);
            this.groupBox16.Controls.Add(this.label28);
            this.groupBox16.Controls.Add(this.ComboBox_EPC5);
            this.groupBox16.Location = new System.Drawing.Point(485, 459);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(325, 116);
            this.groupBox16.TabIndex = 7;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "EAS Alarm";
            // 
            // Label_Alarm
            // 
            this.Label_Alarm.AutoSize = true;
            this.Label_Alarm.Font = new System.Drawing.Font("Microsoft Sans Serif", 30.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)), true);
            this.Label_Alarm.ForeColor = System.Drawing.Color.Red;
            this.Label_Alarm.Location = new System.Drawing.Point(243, 35);
            this.Label_Alarm.Name = "Label_Alarm";
            this.Label_Alarm.Size = new System.Drawing.Size(51, 46);
            this.Label_Alarm.TabIndex = 14;
            this.Label_Alarm.Text = "l";
            // 
            // Button_CheckAlarm
            // 
            this.Button_CheckAlarm.Enabled = false;
            this.Button_CheckAlarm.Location = new System.Drawing.Point(226, 86);
            this.Button_CheckAlarm.Name = "Button_CheckAlarm";
            this.Button_CheckAlarm.Size = new System.Drawing.Size(89, 25);
            this.Button_CheckAlarm.TabIndex = 13;
            this.Button_CheckAlarm.Text = "Check Alarm";
            this.Button_CheckAlarm.UseVisualStyleBackColor = true;
            this.Button_CheckAlarm.Click += new System.EventHandler(this.Button_CheckAlarm_Click);
            // 
            // Button_SetEASAlarm_G2
            // 
            this.Button_SetEASAlarm_G2.Location = new System.Drawing.Point(110, 86);
            this.Button_SetEASAlarm_G2.Name = "Button_SetEASAlarm_G2";
            this.Button_SetEASAlarm_G2.Size = new System.Drawing.Size(97, 25);
            this.Button_SetEASAlarm_G2.TabIndex = 12;
            this.Button_SetEASAlarm_G2.Text = "Alarm Setting";
            this.Button_SetEASAlarm_G2.UseVisualStyleBackColor = true;
            this.Button_SetEASAlarm_G2.Click += new System.EventHandler(this.Button_SetEASAlarm_G2_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.NoAlarm_G2);
            this.groupBox17.Controls.Add(this.Alarm_G2);
            this.groupBox17.Location = new System.Drawing.Point(6, 64);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(100, 48);
            this.groupBox17.TabIndex = 11;
            this.groupBox17.TabStop = false;
            // 
            // NoAlarm_G2
            // 
            this.NoAlarm_G2.AutoSize = true;
            this.NoAlarm_G2.Location = new System.Drawing.Point(5, 28);
            this.NoAlarm_G2.Name = "NoAlarm_G2";
            this.NoAlarm_G2.Size = new System.Drawing.Size(68, 17);
            this.NoAlarm_G2.TabIndex = 1;
            this.NoAlarm_G2.TabStop = true;
            this.NoAlarm_G2.Text = "No Alarm";
            this.NoAlarm_G2.UseVisualStyleBackColor = true;
            // 
            // Alarm_G2
            // 
            this.Alarm_G2.AutoSize = true;
            this.Alarm_G2.Location = new System.Drawing.Point(5, 11);
            this.Alarm_G2.Name = "Alarm_G2";
            this.Alarm_G2.Size = new System.Drawing.Size(51, 17);
            this.Alarm_G2.TabIndex = 0;
            this.Alarm_G2.TabStop = true;
            this.Alarm_G2.Text = "Alarm";
            this.Alarm_G2.UseVisualStyleBackColor = true;
            // 
            // Edit_AccessCode5
            // 
            this.Edit_AccessCode5.Location = new System.Drawing.Point(107, 41);
            this.Edit_AccessCode5.MaxLength = 8;
            this.Edit_AccessCode5.Name = "Edit_AccessCode5";
            this.Edit_AccessCode5.Size = new System.Drawing.Size(100, 20);
            this.Edit_AccessCode5.TabIndex = 10;
            this.Edit_AccessCode5.Text = "00000000";
            this.Edit_AccessCode5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 38);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(91, 26);
            this.label28.TabIndex = 9;
            this.label28.Text = "Access Password\r\n(8 Hex):";
            // 
            // ComboBox_EPC5
            // 
            this.ComboBox_EPC5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC5.FormattingEnabled = true;
            this.ComboBox_EPC5.Location = new System.Drawing.Point(6, 14);
            this.ComboBox_EPC5.Name = "ComboBox_EPC5";
            this.ComboBox_EPC5.Size = new System.Drawing.Size(313, 21);
            this.ComboBox_EPC5.TabIndex = 8;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.Button_CheckReadProtected_G2);
            this.groupBox15.Controls.Add(this.Button_RemoveReadProtect_G2);
            this.groupBox15.Controls.Add(this.Button_SetMultiReadProtect_G2);
            this.groupBox15.Controls.Add(this.Button_SetReadProtect_G2);
            this.groupBox15.Controls.Add(this.Edit_AccessCode4);
            this.groupBox15.Controls.Add(this.label27);
            this.groupBox15.Controls.Add(this.ComboBox_EPC4);
            this.groupBox15.Location = new System.Drawing.Point(485, 269);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(325, 190);
            this.groupBox15.TabIndex = 6;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Read Protection";
            // 
            // Button_CheckReadProtected_G2
            // 
            this.Button_CheckReadProtected_G2.Enabled = false;
            this.Button_CheckReadProtected_G2.Location = new System.Drawing.Point(6, 159);
            this.Button_CheckReadProtected_G2.Name = "Button_CheckReadProtected_G2";
            this.Button_CheckReadProtected_G2.Size = new System.Drawing.Size(313, 25);
            this.Button_CheckReadProtected_G2.TabIndex = 6;
            this.Button_CheckReadProtected_G2.Text = "Detect Single Tag Read Protection without EPC Password";
            this.Button_CheckReadProtected_G2.UseVisualStyleBackColor = true;
            this.Button_CheckReadProtected_G2.Click += new System.EventHandler(this.Button_CheckReadProtected_G2_Click);
            // 
            // Button_RemoveReadProtect_G2
            // 
            this.Button_RemoveReadProtect_G2.Enabled = false;
            this.Button_RemoveReadProtect_G2.Location = new System.Drawing.Point(6, 130);
            this.Button_RemoveReadProtect_G2.Name = "Button_RemoveReadProtect_G2";
            this.Button_RemoveReadProtect_G2.Size = new System.Drawing.Size(313, 25);
            this.Button_RemoveReadProtect_G2.TabIndex = 5;
            this.Button_RemoveReadProtect_G2.Text = "Reset Single Tag Read Protection without EPC";
            this.Button_RemoveReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_RemoveReadProtect_G2.Click += new System.EventHandler(this.Button_RemoveReadProtect_G2_Click);
            // 
            // Button_SetMultiReadProtect_G2
            // 
            this.Button_SetMultiReadProtect_G2.Enabled = false;
            this.Button_SetMultiReadProtect_G2.Location = new System.Drawing.Point(6, 101);
            this.Button_SetMultiReadProtect_G2.Name = "Button_SetMultiReadProtect_G2";
            this.Button_SetMultiReadProtect_G2.Size = new System.Drawing.Size(313, 25);
            this.Button_SetMultiReadProtect_G2.TabIndex = 4;
            this.Button_SetMultiReadProtect_G2.Text = "Set Single Tag Read Protection without EPC";
            this.Button_SetMultiReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_SetMultiReadProtect_G2.Click += new System.EventHandler(this.Button_SetMultiReadProtect_G2_Click);
            // 
            // Button_SetReadProtect_G2
            // 
            this.Button_SetReadProtect_G2.Enabled = false;
            this.Button_SetReadProtect_G2.Location = new System.Drawing.Point(6, 72);
            this.Button_SetReadProtect_G2.Name = "Button_SetReadProtect_G2";
            this.Button_SetReadProtect_G2.Size = new System.Drawing.Size(313, 25);
            this.Button_SetReadProtect_G2.TabIndex = 3;
            this.Button_SetReadProtect_G2.Text = "Set Single Tag Read Protection";
            this.Button_SetReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_SetReadProtect_G2.Click += new System.EventHandler(this.Button_SetReadProtect_G2_Click);
            // 
            // Edit_AccessCode4
            // 
            this.Edit_AccessCode4.Location = new System.Drawing.Point(107, 43);
            this.Edit_AccessCode4.MaxLength = 8;
            this.Edit_AccessCode4.Name = "Edit_AccessCode4";
            this.Edit_AccessCode4.Size = new System.Drawing.Size(100, 20);
            this.Edit_AccessCode4.TabIndex = 2;
            this.Edit_AccessCode4.Text = "00000000";
            this.Edit_AccessCode4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 40);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(91, 26);
            this.label27.TabIndex = 1;
            this.label27.Text = "Access Password\r\n(8 Hex):";
            // 
            // ComboBox_EPC4
            // 
            this.ComboBox_EPC4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC4.FormattingEnabled = true;
            this.ComboBox_EPC4.Location = new System.Drawing.Point(8, 15);
            this.ComboBox_EPC4.Name = "ComboBox_EPC4";
            this.ComboBox_EPC4.Size = new System.Drawing.Size(311, 21);
            this.ComboBox_EPC4.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.Button_WriteEPC_G2);
            this.groupBox14.Controls.Add(this.Edit_AccessCode3);
            this.groupBox14.Controls.Add(this.label26);
            this.groupBox14.Controls.Add(this.Edit_WriteEPC);
            this.groupBox14.Controls.Add(this.label25);
            this.groupBox14.Location = new System.Drawing.Point(485, 187);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(325, 79);
            this.groupBox14.TabIndex = 5;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Write EPC(Random write one tag in the antenna)";
            // 
            // Button_WriteEPC_G2
            // 
            this.Button_WriteEPC_G2.Enabled = false;
            this.Button_WriteEPC_G2.Location = new System.Drawing.Point(244, 48);
            this.Button_WriteEPC_G2.Name = "Button_WriteEPC_G2";
            this.Button_WriteEPC_G2.Size = new System.Drawing.Size(75, 25);
            this.Button_WriteEPC_G2.TabIndex = 4;
            this.Button_WriteEPC_G2.Text = "Write EPC";
            this.Button_WriteEPC_G2.UseVisualStyleBackColor = true;
            this.Button_WriteEPC_G2.Click += new System.EventHandler(this.Button_WriteEPC_G2_Click);
            // 
            // Edit_AccessCode3
            // 
            this.Edit_AccessCode3.Location = new System.Drawing.Point(107, 50);
            this.Edit_AccessCode3.MaxLength = 8;
            this.Edit_AccessCode3.Name = "Edit_AccessCode3";
            this.Edit_AccessCode3.Size = new System.Drawing.Size(100, 20);
            this.Edit_AccessCode3.TabIndex = 3;
            this.Edit_AccessCode3.Text = "00000000";
            this.Edit_AccessCode3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 44);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(91, 26);
            this.label26.TabIndex = 2;
            this.label26.Text = "Access Password\r\n(8 Hex):";
            // 
            // Edit_WriteEPC
            // 
            this.Edit_WriteEPC.Location = new System.Drawing.Point(77, 18);
            this.Edit_WriteEPC.MaxLength = 60;
            this.Edit_WriteEPC.Name = "Edit_WriteEPC";
            this.Edit_WriteEPC.Size = new System.Drawing.Size(242, 20);
            this.Edit_WriteEPC.TabIndex = 1;
            this.Edit_WriteEPC.Text = "0000";
            this.Edit_WriteEPC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 15);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 26);
            this.label25.TabIndex = 0;
            this.label25.Text = "Write EPC:\r\n(1-15Word)";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.Button_DestroyCard);
            this.groupBox13.Controls.Add(this.Edit_DestroyCode);
            this.groupBox13.Controls.Add(this.label24);
            this.groupBox13.Controls.Add(this.ComboBox_EPC3);
            this.groupBox13.Location = new System.Drawing.Point(485, 102);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(325, 83);
            this.groupBox13.TabIndex = 4;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Kill Tag";
            // 
            // Button_DestroyCard
            // 
            this.Button_DestroyCard.Location = new System.Drawing.Point(244, 50);
            this.Button_DestroyCard.Name = "Button_DestroyCard";
            this.Button_DestroyCard.Size = new System.Drawing.Size(75, 25);
            this.Button_DestroyCard.TabIndex = 3;
            this.Button_DestroyCard.Text = "Kill Tag";
            this.Button_DestroyCard.UseVisualStyleBackColor = true;
            this.Button_DestroyCard.Click += new System.EventHandler(this.Button_DestroyCard_Click);
            // 
            // Edit_DestroyCode
            // 
            this.Edit_DestroyCode.Location = new System.Drawing.Point(115, 52);
            this.Edit_DestroyCode.MaxLength = 8;
            this.Edit_DestroyCode.Name = "Edit_DestroyCode";
            this.Edit_DestroyCode.Size = new System.Drawing.Size(92, 20);
            this.Edit_DestroyCode.TabIndex = 2;
            this.Edit_DestroyCode.Text = "00000000";
            this.Edit_DestroyCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 50);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(69, 26);
            this.label24.TabIndex = 1;
            this.label24.Text = "Kill Password\r\n(8 Hex):";
            // 
            // ComboBox_EPC3
            // 
            this.ComboBox_EPC3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC3.FormattingEnabled = true;
            this.ComboBox_EPC3.Location = new System.Drawing.Point(8, 22);
            this.ComboBox_EPC3.Name = "ComboBox_EPC3";
            this.ComboBox_EPC3.Size = new System.Drawing.Size(311, 21);
            this.ComboBox_EPC3.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.CheckBox_TID);
            this.groupBox12.Controls.Add(this.groupBox33);
            this.groupBox12.Controls.Add(this.Button_QueryTag);
            this.groupBox12.Controls.Add(this.ComboBox_IntervalTime);
            this.groupBox12.Controls.Add(this.label23);
            this.groupBox12.Location = new System.Drawing.Point(485, 0);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(325, 101);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Query Tag";
            // 
            // CheckBox_TID
            // 
            this.CheckBox_TID.AutoSize = true;
            this.CheckBox_TID.Location = new System.Drawing.Point(226, 65);
            this.CheckBox_TID.Name = "CheckBox_TID";
            this.CheckBox_TID.Size = new System.Drawing.Size(44, 17);
            this.CheckBox_TID.TabIndex = 6;
            this.CheckBox_TID.Text = "TID";
            this.CheckBox_TID.UseVisualStyleBackColor = true;
            this.CheckBox_TID.CheckedChanged += new System.EventHandler(this.CheckBox_TID_CheckedChanged);
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.textBox5);
            this.groupBox33.Controls.Add(this.label55);
            this.groupBox33.Controls.Add(this.textBox4);
            this.groupBox33.Controls.Add(this.label54);
            this.groupBox33.Location = new System.Drawing.Point(6, 43);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(209, 52);
            this.groupBox33.TabIndex = 5;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Query TID Parameter";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(167, 15);
            this.textBox5.MaxLength = 2;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(37, 20);
            this.textBox5.TabIndex = 3;
            this.textBox5.Text = "04";
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(126, 25);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(31, 13);
            this.label55.TabIndex = 2;
            this.label55.Text = "Len：";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(71, 16);
            this.textBox4.MaxLength = 2;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(37, 20);
            this.textBox4.TabIndex = 1;
            this.textBox4.Text = "02";
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(4, 26);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(57, 13);
            this.label54.TabIndex = 0;
            this.label54.Text = "StartAddr：";
            // 
            // Button_QueryTag
            // 
            this.Button_QueryTag.Enabled = false;
            this.Button_QueryTag.Location = new System.Drawing.Point(227, 20);
            this.Button_QueryTag.Name = "Button_QueryTag";
            this.Button_QueryTag.Size = new System.Drawing.Size(75, 25);
            this.Button_QueryTag.TabIndex = 2;
            this.Button_QueryTag.Text = "Query Tag";
            this.Button_QueryTag.UseVisualStyleBackColor = true;
            this.Button_QueryTag.Click += new System.EventHandler(this.Button_QueryTag_Click);
            // 
            // ComboBox_IntervalTime
            // 
            this.ComboBox_IntervalTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_IntervalTime.FormattingEnabled = true;
            this.ComboBox_IntervalTime.Location = new System.Drawing.Point(101, 22);
            this.ComboBox_IntervalTime.Name = "ComboBox_IntervalTime";
            this.ComboBox_IntervalTime.Size = new System.Drawing.Size(120, 21);
            this.ComboBox_IntervalTime.TabIndex = 1;
            this.ComboBox_IntervalTime.SelectedIndexChanged += new System.EventHandler(this.ComboBox_IntervalTime_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(74, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Read Interval:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Button_SetProtectState);
            this.groupBox7.Controls.Add(this.textBox2);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.groupBox11);
            this.groupBox7.Controls.Add(this.groupBox10);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.ComboBox_EPC1);
            this.groupBox7.Location = new System.Drawing.Point(1, 449);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(481, 226);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Set Protect For Reading Or Writing";
            // 
            // Button_SetProtectState
            // 
            this.Button_SetProtectState.Location = new System.Drawing.Point(375, 196);
            this.Button_SetProtectState.Name = "Button_SetProtectState";
            this.Button_SetProtectState.Size = new System.Drawing.Size(99, 25);
            this.Button_SetProtectState.TabIndex = 6;
            this.Button_SetProtectState.Text = "Set Protect";
            this.Button_SetProtectState.UseVisualStyleBackColor = true;
            this.Button_SetProtectState.Click += new System.EventHandler(this.Button_SetProtectState_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(263, 198);
            this.textBox2.MaxLength = 8;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 5;
            this.textBox2.Text = "00000000";
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(261, 179);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(131, 13);
            this.label22.TabIndex = 4;
            this.label22.Text = "Access Password (8 Hex):";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.AlwaysNot2);
            this.groupBox11.Controls.Add(this.Always2);
            this.groupBox11.Controls.Add(this.Proect2);
            this.groupBox11.Controls.Add(this.NoProect2);
            this.groupBox11.Location = new System.Drawing.Point(258, 47);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(217, 130);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Lock of EPC TID and User Bank";
            // 
            // AlwaysNot2
            // 
            this.AlwaysNot2.AutoSize = true;
            this.AlwaysNot2.Location = new System.Drawing.Point(5, 105);
            this.AlwaysNot2.Name = "AlwaysNot2";
            this.AlwaysNot2.Size = new System.Drawing.Size(99, 17);
            this.AlwaysNot2.TabIndex = 3;
            this.AlwaysNot2.TabStop = true;
            this.AlwaysNot2.Text = "Never writeable";
            this.AlwaysNot2.UseVisualStyleBackColor = true;
            // 
            // Always2
            // 
            this.Always2.AutoSize = true;
            this.Always2.Location = new System.Drawing.Point(5, 77);
            this.Always2.Name = "Always2";
            this.Always2.Size = new System.Drawing.Size(128, 17);
            this.Always2.TabIndex = 2;
            this.Always2.TabStop = true;
            this.Always2.Text = "Permanently writeable";
            this.Always2.UseVisualStyleBackColor = true;
            // 
            // Proect2
            // 
            this.Proect2.AutoSize = true;
            this.Proect2.Location = new System.Drawing.Point(5, 49);
            this.Proect2.Name = "Proect2";
            this.Proect2.Size = new System.Drawing.Size(178, 17);
            this.Proect2.TabIndex = 1;
            this.Proect2.TabStop = true;
            this.Proect2.Text = "Writeable from the secured state";
            this.Proect2.UseVisualStyleBackColor = true;
            // 
            // NoProect2
            // 
            this.NoProect2.AutoSize = true;
            this.NoProect2.Location = new System.Drawing.Point(5, 21);
            this.NoProect2.Name = "NoProect2";
            this.NoProect2.Size = new System.Drawing.Size(139, 17);
            this.NoProect2.TabIndex = 0;
            this.NoProect2.TabStop = true;
            this.NoProect2.Text = "Writeable from any state";
            this.NoProect2.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.P_User);
            this.groupBox10.Controls.Add(this.P_TID);
            this.groupBox10.Controls.Add(this.P_EPC);
            this.groupBox10.Controls.Add(this.P_Reserve);
            this.groupBox10.Location = new System.Drawing.Point(259, 13);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(215, 34);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            // 
            // P_User
            // 
            this.P_User.AutoSize = true;
            this.P_User.Location = new System.Drawing.Point(162, 12);
            this.P_User.Name = "P_User";
            this.P_User.Size = new System.Drawing.Size(47, 17);
            this.P_User.TabIndex = 3;
            this.P_User.TabStop = true;
            this.P_User.Text = "User";
            this.P_User.UseVisualStyleBackColor = true;
            this.P_User.CheckedChanged += new System.EventHandler(this.P_User_CheckedChanged);
            // 
            // P_TID
            // 
            this.P_TID.AutoSize = true;
            this.P_TID.Location = new System.Drawing.Point(119, 12);
            this.P_TID.Name = "P_TID";
            this.P_TID.Size = new System.Drawing.Size(43, 17);
            this.P_TID.TabIndex = 2;
            this.P_TID.TabStop = true;
            this.P_TID.Text = "TID";
            this.P_TID.UseVisualStyleBackColor = true;
            this.P_TID.CheckedChanged += new System.EventHandler(this.P_TID_CheckedChanged);
            // 
            // P_EPC
            // 
            this.P_EPC.AutoSize = true;
            this.P_EPC.Location = new System.Drawing.Point(77, 12);
            this.P_EPC.Name = "P_EPC";
            this.P_EPC.Size = new System.Drawing.Size(46, 17);
            this.P_EPC.TabIndex = 1;
            this.P_EPC.TabStop = true;
            this.P_EPC.Text = "EPC";
            this.P_EPC.UseVisualStyleBackColor = true;
            this.P_EPC.CheckedChanged += new System.EventHandler(this.P_EPC_CheckedChanged);
            // 
            // P_Reserve
            // 
            this.P_Reserve.AutoSize = true;
            this.P_Reserve.Location = new System.Drawing.Point(4, 12);
            this.P_Reserve.Name = "P_Reserve";
            this.P_Reserve.Size = new System.Drawing.Size(71, 17);
            this.P_Reserve.TabIndex = 0;
            this.P_Reserve.TabStop = true;
            this.P_Reserve.Text = "Password";
            this.P_Reserve.UseVisualStyleBackColor = true;
            this.P_Reserve.CheckedChanged += new System.EventHandler(this.P_Reserve_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.AlwaysNot);
            this.groupBox8.Controls.Add(this.Always);
            this.groupBox8.Controls.Add(this.Proect);
            this.groupBox8.Controls.Add(this.NoProect);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Location = new System.Drawing.Point(4, 38);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(248, 185);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Lock of Password";
            // 
            // AlwaysNot
            // 
            this.AlwaysNot.AutoSize = true;
            this.AlwaysNot.Location = new System.Drawing.Point(6, 161);
            this.AlwaysNot.Name = "AlwaysNot";
            this.AlwaysNot.Size = new System.Drawing.Size(164, 17);
            this.AlwaysNot.TabIndex = 4;
            this.AlwaysNot.TabStop = true;
            this.AlwaysNot.Text = "Never readable and writeable";
            this.AlwaysNot.UseVisualStyleBackColor = true;
            // 
            // Always
            // 
            this.Always.AutoSize = true;
            this.Always.Location = new System.Drawing.Point(6, 135);
            this.Always.Name = "Always";
            this.Always.Size = new System.Drawing.Size(193, 17);
            this.Always.TabIndex = 3;
            this.Always.TabStop = true;
            this.Always.Text = "Permanently readable and writeable";
            this.Always.UseVisualStyleBackColor = true;
            // 
            // Proect
            // 
            this.Proect.AutoSize = true;
            this.Proect.Location = new System.Drawing.Point(6, 100);
            this.Proect.Name = "Proect";
            this.Proect.Size = new System.Drawing.Size(181, 30);
            this.Proect.TabIndex = 2;
            this.Proect.TabStop = true;
            this.Proect.Text = "Readable and writeable from the \r\nsecured state";
            this.Proect.UseVisualStyleBackColor = true;
            // 
            // NoProect
            // 
            this.NoProect.AutoSize = true;
            this.NoProect.Location = new System.Drawing.Point(6, 73);
            this.NoProect.Name = "NoProect";
            this.NoProect.Size = new System.Drawing.Size(166, 30);
            this.NoProect.TabIndex = 1;
            this.NoProect.TabStop = true;
            this.NoProect.Text = "Readable and  writeable from \r\nany state";
            this.NoProect.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.AccessCode);
            this.groupBox9.Controls.Add(this.DestroyCode);
            this.groupBox9.Location = new System.Drawing.Point(5, 20);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(237, 52);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            // 
            // AccessCode
            // 
            this.AccessCode.AutoSize = true;
            this.AccessCode.Location = new System.Drawing.Point(108, 22);
            this.AccessCode.Name = "AccessCode";
            this.AccessCode.Size = new System.Drawing.Size(109, 17);
            this.AccessCode.TabIndex = 1;
            this.AccessCode.TabStop = true;
            this.AccessCode.Text = "Access Password";
            this.AccessCode.UseVisualStyleBackColor = true;
            // 
            // DestroyCode
            // 
            this.DestroyCode.AutoSize = true;
            this.DestroyCode.Location = new System.Drawing.Point(6, 22);
            this.DestroyCode.Name = "DestroyCode";
            this.DestroyCode.Size = new System.Drawing.Size(87, 17);
            this.DestroyCode.TabIndex = 0;
            this.DestroyCode.TabStop = true;
            this.DestroyCode.Text = "Kill Password";
            this.DestroyCode.UseVisualStyleBackColor = true;
            // 
            // ComboBox_EPC1
            // 
            this.ComboBox_EPC1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC1.FormattingEnabled = true;
            this.ComboBox_EPC1.Location = new System.Drawing.Point(4, 15);
            this.ComboBox_EPC1.Name = "ComboBox_EPC1";
            this.ComboBox_EPC1.Size = new System.Drawing.Size(249, 21);
            this.ComboBox_EPC1.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox_pc);
            this.groupBox5.Controls.Add(this.checkBox_pc);
            this.groupBox5.Controls.Add(this.BlockWrite);
            this.groupBox5.Controls.Add(this.ComboBox_EPC2);
            this.groupBox5.Controls.Add(this.button7);
            this.groupBox5.Controls.Add(this.Button_BlockErase);
            this.groupBox5.Controls.Add(this.Button_DataWrite);
            this.groupBox5.Controls.Add(this.SpeedButton_Read_G2);
            this.groupBox5.Controls.Add(this.Edit_WriteData);
            this.groupBox5.Controls.Add(this.Edit_AccessCode2);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Controls.Add(this.Edit_WordPtr);
            this.groupBox5.Controls.Add(this.listBox1);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Location = new System.Drawing.Point(1, 229);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(481, 220);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Read Data / Write Data / Block Erase";
            // 
            // textBox_pc
            // 
            this.textBox_pc.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox_pc.Location = new System.Drawing.Point(440, 15);
            this.textBox_pc.Name = "textBox_pc";
            this.textBox_pc.ReadOnly = true;
            this.textBox_pc.Size = new System.Drawing.Size(34, 20);
            this.textBox_pc.TabIndex = 21;
            this.textBox_pc.Text = "0800";
            // 
            // checkBox_pc
            // 
            this.checkBox_pc.AutoSize = true;
            this.checkBox_pc.Location = new System.Drawing.Point(302, 17);
            this.checkBox_pc.Name = "checkBox_pc";
            this.checkBox_pc.Size = new System.Drawing.Size(127, 17);
            this.checkBox_pc.TabIndex = 20;
            this.checkBox_pc.Text = "Compute and add PC";
            this.checkBox_pc.UseVisualStyleBackColor = true;
            this.checkBox_pc.CheckedChanged += new System.EventHandler(this.checkBox_pc_CheckedChanged);
            // 
            // BlockWrite
            // 
            this.BlockWrite.Location = new System.Drawing.Point(97, 190);
            this.BlockWrite.Name = "BlockWrite";
            this.BlockWrite.Size = new System.Drawing.Size(73, 25);
            this.BlockWrite.TabIndex = 16;
            this.BlockWrite.Text = "BlockWrite";
            this.BlockWrite.UseVisualStyleBackColor = true;
            this.BlockWrite.Click += new System.EventHandler(this.BlockWrite_Click);
            // 
            // ComboBox_EPC2
            // 
            this.ComboBox_EPC2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC2.FormattingEnabled = true;
            this.ComboBox_EPC2.Location = new System.Drawing.Point(4, 17);
            this.ComboBox_EPC2.Name = "ComboBox_EPC2";
            this.ComboBox_EPC2.Size = new System.Drawing.Size(292, 21);
            this.ComboBox_EPC2.TabIndex = 15;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(253, 190);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(43, 25);
            this.button7.TabIndex = 14;
            this.button7.Text = "Clear";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Button_BlockErase
            // 
            this.Button_BlockErase.Location = new System.Drawing.Point(172, 190);
            this.Button_BlockErase.Name = "Button_BlockErase";
            this.Button_BlockErase.Size = new System.Drawing.Size(79, 25);
            this.Button_BlockErase.TabIndex = 13;
            this.Button_BlockErase.Text = "BlockErase";
            this.Button_BlockErase.UseVisualStyleBackColor = true;
            this.Button_BlockErase.Click += new System.EventHandler(this.Button_BlockErase_Click);
            // 
            // Button_DataWrite
            // 
            this.Button_DataWrite.Location = new System.Drawing.Point(52, 190);
            this.Button_DataWrite.Name = "Button_DataWrite";
            this.Button_DataWrite.Size = new System.Drawing.Size(43, 25);
            this.Button_DataWrite.TabIndex = 12;
            this.Button_DataWrite.Text = "Write";
            this.Button_DataWrite.UseVisualStyleBackColor = true;
            this.Button_DataWrite.Click += new System.EventHandler(this.Button_DataWrite_Click);
            // 
            // SpeedButton_Read_G2
            // 
            this.SpeedButton_Read_G2.Location = new System.Drawing.Point(6, 190);
            this.SpeedButton_Read_G2.Name = "SpeedButton_Read_G2";
            this.SpeedButton_Read_G2.Size = new System.Drawing.Size(44, 25);
            this.SpeedButton_Read_G2.TabIndex = 11;
            this.SpeedButton_Read_G2.Text = "Read";
            this.SpeedButton_Read_G2.UseVisualStyleBackColor = true;
            this.SpeedButton_Read_G2.Click += new System.EventHandler(this.SpeedButton_Read_G2_Click);
            // 
            // Edit_WriteData
            // 
            this.Edit_WriteData.Location = new System.Drawing.Point(116, 165);
            this.Edit_WriteData.Name = "Edit_WriteData";
            this.Edit_WriteData.Size = new System.Drawing.Size(180, 20);
            this.Edit_WriteData.TabIndex = 10;
            this.Edit_WriteData.Text = "0000";
            this.Edit_WriteData.TextChanged += new System.EventHandler(this.Edit_WriteData_TextChanged);
            this.Edit_WriteData.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // Edit_AccessCode2
            // 
            this.Edit_AccessCode2.Location = new System.Drawing.Point(155, 137);
            this.Edit_AccessCode2.MaxLength = 8;
            this.Edit_AccessCode2.Name = "Edit_AccessCode2";
            this.Edit_AccessCode2.Size = new System.Drawing.Size(141, 20);
            this.Edit_AccessCode2.TabIndex = 9;
            this.Edit_AccessCode2.Text = "00000000";
            this.Edit_AccessCode2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(205, 107);
            this.textBox1.MaxLength = 3;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(91, 20);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "4";
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_Len_6B_KeyPress);
            // 
            // Edit_WordPtr
            // 
            this.Edit_WordPtr.Location = new System.Drawing.Point(205, 74);
            this.Edit_WordPtr.MaxLength = 2;
            this.Edit_WordPtr.Name = "Edit_WordPtr";
            this.Edit_WordPtr.Size = new System.Drawing.Size(91, 20);
            this.Edit_WordPtr.TabIndex = 7;
            this.Edit_WordPtr.Text = "00";
            this.Edit_WordPtr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(301, 41);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(174, 173);
            this.listBox1.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(8, 170);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 13);
            this.label21.TabIndex = 5;
            this.label21.Text = "Write Data (Hex):";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 140);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(131, 13);
            this.label20.TabIndex = 4;
            this.label20.Text = "Access Password (8 Hex):";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 106);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(172, 26);
            this.label19.TabIndex = 3;
            this.label19.Text = "Length of Data(Read/Block Erase)\r\n(0-120/Word/D):";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 83);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(164, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "Address of Tag Data(Word/Hex):";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.C_User);
            this.groupBox6.Controls.Add(this.C_TID);
            this.groupBox6.Controls.Add(this.C_EPC);
            this.groupBox6.Controls.Add(this.C_Reserve);
            this.groupBox6.Location = new System.Drawing.Point(6, 34);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(290, 34);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            // 
            // C_User
            // 
            this.C_User.AutoSize = true;
            this.C_User.Location = new System.Drawing.Point(207, 12);
            this.C_User.Name = "C_User";
            this.C_User.Size = new System.Drawing.Size(47, 17);
            this.C_User.TabIndex = 3;
            this.C_User.TabStop = true;
            this.C_User.Text = "User";
            this.C_User.UseVisualStyleBackColor = true;
            this.C_User.CheckedChanged += new System.EventHandler(this.C_User_CheckedChanged);
            // 
            // C_TID
            // 
            this.C_TID.AutoSize = true;
            this.C_TID.Location = new System.Drawing.Point(149, 12);
            this.C_TID.Name = "C_TID";
            this.C_TID.Size = new System.Drawing.Size(43, 17);
            this.C_TID.TabIndex = 2;
            this.C_TID.TabStop = true;
            this.C_TID.Text = "TID";
            this.C_TID.UseVisualStyleBackColor = true;
            this.C_TID.CheckedChanged += new System.EventHandler(this.C_TID_CheckedChanged);
            // 
            // C_EPC
            // 
            this.C_EPC.AutoSize = true;
            this.C_EPC.Location = new System.Drawing.Point(90, 12);
            this.C_EPC.Name = "C_EPC";
            this.C_EPC.Size = new System.Drawing.Size(46, 17);
            this.C_EPC.TabIndex = 1;
            this.C_EPC.TabStop = true;
            this.C_EPC.Text = "EPC";
            this.C_EPC.UseVisualStyleBackColor = true;
            this.C_EPC.CheckedChanged += new System.EventHandler(this.C_EPC_CheckedChanged);
            // 
            // C_Reserve
            // 
            this.C_Reserve.AutoSize = true;
            this.C_Reserve.Location = new System.Drawing.Point(4, 12);
            this.C_Reserve.Name = "C_Reserve";
            this.C_Reserve.Size = new System.Drawing.Size(71, 17);
            this.C_Reserve.TabIndex = 0;
            this.C_Reserve.TabStop = true;
            this.C_Reserve.Text = "Password";
            this.C_Reserve.UseVisualStyleBackColor = true;
            this.C_Reserve.CheckedChanged += new System.EventHandler(this.C_Reserve_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.ListView1_EPC);
            this.groupBox4.Location = new System.Drawing.Point(1, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(480, 176);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "List EPC of Tags";
            // 
            // ListView1_EPC
            // 
            this.ListView1_EPC.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.ListView1_EPC.AutoArrange = false;
            this.ListView1_EPC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ListView1_EPC.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.listViewCol_Number,
            this.listViewCol_ID,
            this.listViewCol_Length,
            this.listViewCol_Times});
            this.ListView1_EPC.Dock = System.Windows.Forms.DockStyle.Top;
            this.ListView1_EPC.FullRowSelect = true;
            this.ListView1_EPC.GridLines = true;
            this.ListView1_EPC.HideSelection = false;
            this.ListView1_EPC.Location = new System.Drawing.Point(3, 16);
            this.ListView1_EPC.Name = "ListView1_EPC";
            this.ListView1_EPC.Size = new System.Drawing.Size(474, 149);
            this.ListView1_EPC.TabIndex = 1;
            this.ListView1_EPC.UseCompatibleStateImageBehavior = false;
            this.ListView1_EPC.View = System.Windows.Forms.View.Details;
            // 
            // listViewCol_Number
            // 
            this.listViewCol_Number.Text = "No.";
            this.listViewCol_Number.Width = 40;
            // 
            // listViewCol_ID
            // 
            this.listViewCol_ID.Text = "ID";
            this.listViewCol_ID.Width = 200;
            // 
            // listViewCol_Length
            // 
            this.listViewCol_Length.Text = "EPCLength";
            this.listViewCol_Length.Width = 100;
            // 
            // listViewCol_Times
            // 
            this.listViewCol_Times.Text = "Times";
            // 
            // TabSheet_6B
            // 
            this.TabSheet_6B.Controls.Add(this.groupBox22);
            this.TabSheet_6B.Controls.Add(this.groupBox21);
            this.TabSheet_6B.Controls.Add(this.groupBox20);
            this.TabSheet_6B.Controls.Add(this.groupBox19);
            this.TabSheet_6B.Location = new System.Drawing.Point(4, 22);
            this.TabSheet_6B.Name = "TabSheet_6B";
            this.TabSheet_6B.Size = new System.Drawing.Size(817, 678);
            this.TabSheet_6B.TabIndex = 3;
            this.TabSheet_6B.Text = "18000-6B Test";
            this.TabSheet_6B.UseVisualStyleBackColor = true;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.Edit_WriteData_6B);
            this.groupBox22.Controls.Add(this.label36);
            this.groupBox22.Controls.Add(this.listBox2);
            this.groupBox22.Controls.Add(this.Button_Clear);
            this.groupBox22.Controls.Add(this.Button_Check);
            this.groupBox22.Controls.Add(this.Button_PermanentWrite);
            this.groupBox22.Controls.Add(this.SpeedButton_Write_6B);
            this.groupBox22.Controls.Add(this.SpeedButton_Read_6B);
            this.groupBox22.Controls.Add(this.Edit_Len_6B);
            this.groupBox22.Controls.Add(this.label35);
            this.groupBox22.Controls.Add(this.Edit_StartAddress_6B);
            this.groupBox22.Controls.Add(this.label34);
            this.groupBox22.Controls.Add(this.ComboBox_ID1_6B);
            this.groupBox22.Location = new System.Drawing.Point(328, 340);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(486, 334);
            this.groupBox22.TabIndex = 3;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Read and Write Data Block / Permanently Write  Protect Block of  byte";
            // 
            // Edit_WriteData_6B
            // 
            this.Edit_WriteData_6B.Location = new System.Drawing.Point(179, 92);
            this.Edit_WriteData_6B.Name = "Edit_WriteData_6B";
            this.Edit_WriteData_6B.Size = new System.Drawing.Size(301, 20);
            this.Edit_WriteData_6B.TabIndex = 12;
            this.Edit_WriteData_6B.Text = "0000";
            this.Edit_WriteData_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 95);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(139, 13);
            this.label36.TabIndex = 11;
            this.label36.Text = "Write Data (1-32 Byte/Hex):";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(6, 155);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(474, 173);
            this.listBox2.TabIndex = 10;
            // 
            // Button_Clear
            // 
            this.Button_Clear.Location = new System.Drawing.Point(429, 124);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Size = new System.Drawing.Size(51, 25);
            this.Button_Clear.TabIndex = 9;
            this.Button_Clear.Text = "Clear";
            this.Button_Clear.UseVisualStyleBackColor = true;
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Button_Check
            // 
            this.Button_Check.Location = new System.Drawing.Point(348, 124);
            this.Button_Check.Name = "Button_Check";
            this.Button_Check.Size = new System.Drawing.Size(75, 25);
            this.Button_Check.TabIndex = 8;
            this.Button_Check.Text = "Check Protect";
            this.Button_Check.UseVisualStyleBackColor = true;
            this.Button_Check.Click += new System.EventHandler(this.Button_Check_Click);
            // 
            // Button_PermanentWrite
            // 
            this.Button_PermanentWrite.Location = new System.Drawing.Point(170, 124);
            this.Button_PermanentWrite.Name = "Button_PermanentWrite";
            this.Button_PermanentWrite.Size = new System.Drawing.Size(172, 25);
            this.Button_PermanentWrite.TabIndex = 7;
            this.Button_PermanentWrite.Text = "Permanently Write  Protect";
            this.Button_PermanentWrite.UseVisualStyleBackColor = true;
            this.Button_PermanentWrite.Click += new System.EventHandler(this.Button_PermanentWrite_Click);
            // 
            // SpeedButton_Write_6B
            // 
            this.SpeedButton_Write_6B.Location = new System.Drawing.Point(89, 124);
            this.SpeedButton_Write_6B.Name = "SpeedButton_Write_6B";
            this.SpeedButton_Write_6B.Size = new System.Drawing.Size(75, 25);
            this.SpeedButton_Write_6B.TabIndex = 6;
            this.SpeedButton_Write_6B.Text = "Write";
            this.SpeedButton_Write_6B.UseVisualStyleBackColor = true;
            this.SpeedButton_Write_6B.Click += new System.EventHandler(this.SpeedButton_Write_6B_Click);
            // 
            // SpeedButton_Read_6B
            // 
            this.SpeedButton_Read_6B.Location = new System.Drawing.Point(8, 124);
            this.SpeedButton_Read_6B.Name = "SpeedButton_Read_6B";
            this.SpeedButton_Read_6B.Size = new System.Drawing.Size(75, 25);
            this.SpeedButton_Read_6B.TabIndex = 5;
            this.SpeedButton_Read_6B.Text = "Read";
            this.SpeedButton_Read_6B.UseVisualStyleBackColor = true;
            this.SpeedButton_Read_6B.Click += new System.EventHandler(this.SpeedButton_Read_6B_Click);
            // 
            // Edit_Len_6B
            // 
            this.Edit_Len_6B.Location = new System.Drawing.Point(382, 57);
            this.Edit_Len_6B.MaxLength = 2;
            this.Edit_Len_6B.Name = "Edit_Len_6B";
            this.Edit_Len_6B.Size = new System.Drawing.Size(100, 20);
            this.Edit_Len_6B.TabIndex = 4;
            this.Edit_Len_6B.Text = "12";
            this.Edit_Len_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_Len_6B_KeyPress);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(283, 57);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(81, 26);
            this.label35.TabIndex = 3;
            this.label35.Text = "Length of Data:\r\n(1-32/Byte/D)";
            // 
            // Edit_StartAddress_6B
            // 
            this.Edit_StartAddress_6B.Location = new System.Drawing.Point(143, 57);
            this.Edit_StartAddress_6B.MaxLength = 2;
            this.Edit_StartAddress_6B.Name = "Edit_StartAddress_6B";
            this.Edit_StartAddress_6B.Size = new System.Drawing.Size(100, 20);
            this.Edit_StartAddress_6B.TabIndex = 2;
            this.Edit_StartAddress_6B.Text = "00";
            this.Edit_StartAddress_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 54);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(109, 26);
            this.label34.TabIndex = 1;
            this.label34.Text = "Start/Protect Address\r\n(00-E9)(Hex):   ";
            // 
            // ComboBox_ID1_6B
            // 
            this.ComboBox_ID1_6B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_ID1_6B.FormattingEnabled = true;
            this.ComboBox_ID1_6B.Location = new System.Drawing.Point(6, 18);
            this.ComboBox_ID1_6B.Name = "ComboBox_ID1_6B";
            this.ComboBox_ID1_6B.Size = new System.Drawing.Size(474, 21);
            this.ComboBox_ID1_6B.TabIndex = 0;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.Edit_ConditionContent_6B);
            this.groupBox21.Controls.Add(this.Edit_Query_StartAddress_6B);
            this.groupBox21.Controls.Add(this.label33);
            this.groupBox21.Controls.Add(this.label32);
            this.groupBox21.Controls.Add(this.Greater_6B);
            this.groupBox21.Controls.Add(this.Less_6B);
            this.groupBox21.Controls.Add(this.Different_6B);
            this.groupBox21.Controls.Add(this.Same_6B);
            this.groupBox21.Location = new System.Drawing.Point(1, 484);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(321, 190);
            this.groupBox21.TabIndex = 2;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Query Tags by Condition";
            // 
            // Edit_ConditionContent_6B
            // 
            this.Edit_ConditionContent_6B.Location = new System.Drawing.Point(181, 156);
            this.Edit_ConditionContent_6B.MaxLength = 8;
            this.Edit_ConditionContent_6B.Name = "Edit_ConditionContent_6B";
            this.Edit_ConditionContent_6B.Size = new System.Drawing.Size(98, 20);
            this.Edit_ConditionContent_6B.TabIndex = 7;
            this.Edit_ConditionContent_6B.Text = "00";
            this.Edit_ConditionContent_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // Edit_Query_StartAddress_6B
            // 
            this.Edit_Query_StartAddress_6B.Location = new System.Drawing.Point(181, 114);
            this.Edit_Query_StartAddress_6B.MaxLength = 2;
            this.Edit_Query_StartAddress_6B.Name = "Edit_Query_StartAddress_6B";
            this.Edit_Query_StartAddress_6B.Size = new System.Drawing.Size(98, 20);
            this.Edit_Query_StartAddress_6B.TabIndex = 6;
            this.Edit_Query_StartAddress_6B.Text = "0";
            this.Edit_Query_StartAddress_6B.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Edit_CmdComAddr_KeyPress);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 159);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(140, 13);
            this.label33.TabIndex = 5;
            this.label33.Text = "Condition(<=8 Hex Number):";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(8, 117);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(141, 13);
            this.label32.TabIndex = 4;
            this.label32.Text = "Address of Tag Data(0-223):";
            // 
            // Greater_6B
            // 
            this.Greater_6B.AutoSize = true;
            this.Greater_6B.Location = new System.Drawing.Point(163, 74);
            this.Greater_6B.Name = "Greater_6B";
            this.Greater_6B.Size = new System.Drawing.Size(131, 17);
            this.Greater_6B.TabIndex = 3;
            this.Greater_6B.TabStop = true;
            this.Greater_6B.Text = "Greater than Condition";
            this.Greater_6B.UseVisualStyleBackColor = true;
            // 
            // Less_6B
            // 
            this.Less_6B.AutoSize = true;
            this.Less_6B.Location = new System.Drawing.Point(8, 74);
            this.Less_6B.Name = "Less_6B";
            this.Less_6B.Size = new System.Drawing.Size(118, 17);
            this.Less_6B.TabIndex = 2;
            this.Less_6B.TabStop = true;
            this.Less_6B.Text = "Less than Condition";
            this.Less_6B.UseVisualStyleBackColor = true;
            // 
            // Different_6B
            // 
            this.Different_6B.AutoSize = true;
            this.Different_6B.Location = new System.Drawing.Point(163, 33);
            this.Different_6B.Name = "Different_6B";
            this.Different_6B.Size = new System.Drawing.Size(112, 17);
            this.Different_6B.TabIndex = 1;
            this.Different_6B.TabStop = true;
            this.Different_6B.Text = "Unequal Condition";
            this.Different_6B.UseVisualStyleBackColor = true;
            // 
            // Same_6B
            // 
            this.Same_6B.AutoSize = true;
            this.Same_6B.Location = new System.Drawing.Point(8, 33);
            this.Same_6B.Name = "Same_6B";
            this.Same_6B.Size = new System.Drawing.Size(99, 17);
            this.Same_6B.TabIndex = 0;
            this.Same_6B.TabStop = true;
            this.Same_6B.Text = "Equal Condition";
            this.Same_6B.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.SpeedButton_Query_6B);
            this.groupBox20.Controls.Add(this.Bycondition_6B);
            this.groupBox20.Controls.Add(this.Byone_6B);
            this.groupBox20.Controls.Add(this.ComboBox_IntervalTime_6B);
            this.groupBox20.Controls.Add(this.label31);
            this.groupBox20.Location = new System.Drawing.Point(1, 340);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(321, 143);
            this.groupBox20.TabIndex = 1;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Query Tag";
            // 
            // SpeedButton_Query_6B
            // 
            this.SpeedButton_Query_6B.Enabled = false;
            this.SpeedButton_Query_6B.Location = new System.Drawing.Point(213, 69);
            this.SpeedButton_Query_6B.Name = "SpeedButton_Query_6B";
            this.SpeedButton_Query_6B.Size = new System.Drawing.Size(102, 53);
            this.SpeedButton_Query_6B.TabIndex = 4;
            this.SpeedButton_Query_6B.Text = "Query";
            this.SpeedButton_Query_6B.UseVisualStyleBackColor = true;
            this.SpeedButton_Query_6B.Click += new System.EventHandler(this.SpeedButton_Query_6B_Click);
            // 
            // Bycondition_6B
            // 
            this.Bycondition_6B.AutoSize = true;
            this.Bycondition_6B.Location = new System.Drawing.Point(8, 105);
            this.Bycondition_6B.Name = "Bycondition_6B";
            this.Bycondition_6B.Size = new System.Drawing.Size(114, 17);
            this.Bycondition_6B.TabIndex = 3;
            this.Bycondition_6B.TabStop = true;
            this.Bycondition_6B.Text = "Query by Condition";
            this.Bycondition_6B.UseVisualStyleBackColor = true;
            this.Bycondition_6B.CheckedChanged += new System.EventHandler(this.Bycondition_6B_CheckedChanged);
            // 
            // Byone_6B
            // 
            this.Byone_6B.AutoSize = true;
            this.Byone_6B.Location = new System.Drawing.Point(8, 69);
            this.Byone_6B.Name = "Byone_6B";
            this.Byone_6B.Size = new System.Drawing.Size(88, 17);
            this.Byone_6B.TabIndex = 2;
            this.Byone_6B.TabStop = true;
            this.Byone_6B.Text = "Query by one";
            this.Byone_6B.UseVisualStyleBackColor = true;
            this.Byone_6B.CheckedChanged += new System.EventHandler(this.Byone_6B_CheckedChanged);
            // 
            // ComboBox_IntervalTime_6B
            // 
            this.ComboBox_IntervalTime_6B.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_IntervalTime_6B.FormattingEnabled = true;
            this.ComboBox_IntervalTime_6B.Location = new System.Drawing.Point(101, 15);
            this.ComboBox_IntervalTime_6B.Name = "ComboBox_IntervalTime_6B";
            this.ComboBox_IntervalTime_6B.Size = new System.Drawing.Size(214, 21);
            this.ComboBox_IntervalTime_6B.TabIndex = 1;
            this.ComboBox_IntervalTime_6B.SelectedIndexChanged += new System.EventHandler(this.ComboBox_IntervalTime_SelectedIndexChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 18);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 13);
            this.label31.TabIndex = 0;
            this.label31.Text = "Read Interval:";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.ListView_ID_6B);
            this.groupBox19.Location = new System.Drawing.Point(1, 3);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(813, 335);
            this.groupBox19.TabIndex = 0;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "List ID of Tags";
            // 
            // ListView_ID_6B
            // 
            this.ListView_ID_6B.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.ListView_ID_6B.AllowDrop = true;
            this.ListView_ID_6B.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.ListView_ID_6B.FullRowSelect = true;
            this.ListView_ID_6B.GridLines = true;
            this.ListView_ID_6B.HideSelection = false;
            this.ListView_ID_6B.HotTracking = true;
            this.ListView_ID_6B.HoverSelection = true;
            this.ListView_ID_6B.Location = new System.Drawing.Point(6, 22);
            this.ListView_ID_6B.Name = "ListView_ID_6B";
            this.ListView_ID_6B.Size = new System.Drawing.Size(801, 306);
            this.ListView_ID_6B.TabIndex = 0;
            this.ListView_ID_6B.UseCompatibleStateImageBehavior = false;
            this.ListView_ID_6B.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "No.";
            this.columnHeader5.Width = 50;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "ID";
            this.columnHeader6.Width = 600;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Times";
            this.columnHeader7.Width = 90;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.Button_GetFreq);
            this.tabPage1.Controls.Add(this.Button_SetFreq);
            this.tabPage1.Controls.Add(this.comboBox8);
            this.tabPage1.Controls.Add(this.label49);
            this.tabPage1.Controls.Add(this.Button_ClearFreq);
            this.tabPage1.Controls.Add(this.Button_StopFreq);
            this.tabPage1.Controls.Add(this.Button_StartFreq);
            this.tabPage1.Controls.Add(this.listBox4);
            this.tabPage1.Controls.Add(this.label52);
            this.tabPage1.Controls.Add(this.label51);
            this.tabPage1.Controls.Add(this.label50);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(817, 678);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "Frequency Analysis";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Button_GetFreq
            // 
            this.Button_GetFreq.Location = new System.Drawing.Point(333, 645);
            this.Button_GetFreq.Name = "Button_GetFreq";
            this.Button_GetFreq.Size = new System.Drawing.Size(49, 25);
            this.Button_GetFreq.TabIndex = 22;
            this.Button_GetFreq.Text = "Get";
            this.Button_GetFreq.UseVisualStyleBackColor = true;
            this.Button_GetFreq.Click += new System.EventHandler(this.Button_GetFreq_Click);
            // 
            // Button_SetFreq
            // 
            this.Button_SetFreq.Location = new System.Drawing.Point(276, 645);
            this.Button_SetFreq.Name = "Button_SetFreq";
            this.Button_SetFreq.Size = new System.Drawing.Size(51, 25);
            this.Button_SetFreq.TabIndex = 21;
            this.Button_SetFreq.Text = "Set";
            this.Button_SetFreq.UseVisualStyleBackColor = true;
            this.Button_SetFreq.Click += new System.EventHandler(this.Button_SetFreq_Click);
            // 
            // comboBox8
            // 
            this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "Random",
            "Adaptive"});
            this.comboBox8.Location = new System.Drawing.Point(163, 648);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(107, 21);
            this.comboBox8.TabIndex = 20;
            this.comboBox8.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(9, 651);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(133, 13);
            this.label49.TabIndex = 19;
            this.label49.Text = "Frequency hopping mode：";
            // 
            // Button_ClearFreq
            // 
            this.Button_ClearFreq.Location = new System.Drawing.Point(726, 645);
            this.Button_ClearFreq.Name = "Button_ClearFreq";
            this.Button_ClearFreq.Size = new System.Drawing.Size(75, 25);
            this.Button_ClearFreq.TabIndex = 7;
            this.Button_ClearFreq.Text = "Clear";
            this.Button_ClearFreq.UseVisualStyleBackColor = true;
            this.Button_ClearFreq.Click += new System.EventHandler(this.Button_ClearFreq_Click);
            // 
            // Button_StopFreq
            // 
            this.Button_StopFreq.Location = new System.Drawing.Point(631, 645);
            this.Button_StopFreq.Name = "Button_StopFreq";
            this.Button_StopFreq.Size = new System.Drawing.Size(75, 25);
            this.Button_StopFreq.TabIndex = 6;
            this.Button_StopFreq.Text = "Stop";
            this.Button_StopFreq.UseVisualStyleBackColor = true;
            this.Button_StopFreq.Click += new System.EventHandler(this.Button_StopFreq_Click);
            // 
            // Button_StartFreq
            // 
            this.Button_StartFreq.Location = new System.Drawing.Point(536, 645);
            this.Button_StartFreq.Name = "Button_StartFreq";
            this.Button_StartFreq.Size = new System.Drawing.Size(75, 25);
            this.Button_StartFreq.TabIndex = 5;
            this.Button_StartFreq.Text = "Start";
            this.Button_StartFreq.UseVisualStyleBackColor = true;
            this.Button_StartFreq.Click += new System.EventHandler(this.Button_StartFreq_Click);
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            this.listBox4.Location = new System.Drawing.Point(14, 35);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(787, 602);
            this.listBox4.TabIndex = 4;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(446, 18);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(62, 13);
            this.label52.TabIndex = 3;
            this.label52.Text = "Percentage";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(235, 18);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(35, 13);
            this.label51.TabIndex = 2;
            this.label51.Text = "Times";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(19, 18);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(57, 13);
            this.label50.TabIndex = 1;
            this.label50.Text = "Frequency";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox36);
            this.tabPage2.Controls.Add(this.groupBox35);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(817, 678);
            this.tabPage2.TabIndex = 5;
            this.tabPage2.Text = "TCPIP Config";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.label62);
            this.groupBox36.Controls.Add(this.label61);
            this.groupBox36.Controls.Add(this.label60);
            this.groupBox36.Controls.Add(this.label59);
            this.groupBox36.Controls.Add(this.label58);
            this.groupBox36.Location = new System.Drawing.Point(6, 488);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(804, 183);
            this.groupBox36.TabIndex = 1;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "Note";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(22, 146);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(470, 13);
            this.label62.TabIndex = 4;
            this.label62.Text = "LED Flashing: Let the device\'s LED flash quickly. It is used to fast distinguish " +
    "a device on the field.";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(22, 114);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(253, 13);
            this.label61.TabIndex = 3;
            this.label61.Text = "Change IP: Change designated device\'s IP address.";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(22, 82);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(275, 13);
            this.label60.TabIndex = 2;
            this.label60.Text = "Configuration: Configure designated device\'s parameters.";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(22, 53);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(594, 13);
            this.label59.TabIndex = 1;
            this.label59.Text = "Specific Search: Search for devices by designated IP address. It is commonly used" +
    " for finding the devices in different subnet.";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(22, 25);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(510, 13);
            this.label58.TabIndex = 0;
            this.label58.Text = "Search: Search local LAN devices by broadcasting. This operation can not find dev" +
    "ices in different subnet.";
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.LEDFlashButton);
            this.groupBox35.Controls.Add(this.changeIpButton);
            this.groupBox35.Controls.Add(this.configButton);
            this.groupBox35.Controls.Add(this.specificSearchButton);
            this.groupBox35.Controls.Add(this.searchButton);
            this.groupBox35.Controls.Add(this.ipList);
            this.groupBox35.Location = new System.Drawing.Point(6, 7);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(804, 475);
            this.groupBox35.TabIndex = 0;
            this.groupBox35.TabStop = false;
            // 
            // LEDFlashButton
            // 
            this.LEDFlashButton.Location = new System.Drawing.Point(634, 273);
            this.LEDFlashButton.Name = "LEDFlashButton";
            this.LEDFlashButton.Size = new System.Drawing.Size(153, 30);
            this.LEDFlashButton.TabIndex = 7;
            this.LEDFlashButton.Text = "LED Flashing";
            this.LEDFlashButton.UseVisualStyleBackColor = true;
            this.LEDFlashButton.Click += new System.EventHandler(this.LEDFlashButton_Click);
            // 
            // changeIpButton
            // 
            this.changeIpButton.Location = new System.Drawing.Point(634, 186);
            this.changeIpButton.Name = "changeIpButton";
            this.changeIpButton.Size = new System.Drawing.Size(153, 30);
            this.changeIpButton.TabIndex = 6;
            this.changeIpButton.Text = "Change  IP";
            this.changeIpButton.UseVisualStyleBackColor = true;
            this.changeIpButton.Click += new System.EventHandler(this.changeIpButton_Click);
            // 
            // configButton
            // 
            this.configButton.Location = new System.Drawing.Point(634, 129);
            this.configButton.Name = "configButton";
            this.configButton.Size = new System.Drawing.Size(153, 30);
            this.configButton.TabIndex = 5;
            this.configButton.Text = "Configuration";
            this.configButton.UseVisualStyleBackColor = true;
            this.configButton.Click += new System.EventHandler(this.configButton_Click);
            // 
            // specificSearchButton
            // 
            this.specificSearchButton.Location = new System.Drawing.Point(634, 74);
            this.specificSearchButton.Name = "specificSearchButton";
            this.specificSearchButton.Size = new System.Drawing.Size(153, 30);
            this.specificSearchButton.TabIndex = 4;
            this.specificSearchButton.Text = "Specific  Search";
            this.specificSearchButton.UseVisualStyleBackColor = true;
            this.specificSearchButton.Click += new System.EventHandler(this.specificSearchButton_Click);
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(634, 22);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(153, 30);
            this.searchButton.TabIndex = 3;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // ipList
            // 
            this.ipList.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.ipList.AutoArrange = false;
            this.ipList.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ipList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ipListNoColumn,
            this.ipListMacColumn,
            this.ipListIpColumn,
            this.ipListUsernameColumn,
            this.ipListDeviceNameColumn});
            this.ipList.FullRowSelect = true;
            this.ipList.GridLines = true;
            this.ipList.HideSelection = false;
            this.ipList.Location = new System.Drawing.Point(8, 21);
            this.ipList.Name = "ipList";
            this.ipList.Size = new System.Drawing.Size(604, 442);
            this.ipList.TabIndex = 2;
            this.ipList.UseCompatibleStateImageBehavior = false;
            this.ipList.View = System.Windows.Forms.View.Details;
            // 
            // ipListNoColumn
            // 
            this.ipListNoColumn.Text = "No.";
            // 
            // ipListMacColumn
            // 
            this.ipListMacColumn.Text = "MAC Address";
            this.ipListMacColumn.Width = 138;
            // 
            // ipListIpColumn
            // 
            this.ipListIpColumn.Text = "IP Address";
            this.ipListIpColumn.Width = 134;
            // 
            // ipListUsernameColumn
            // 
            this.ipListUsernameColumn.Text = "Username";
            this.ipListUsernameColumn.Width = 134;
            // 
            // ipListDeviceNameColumn
            // 
            this.ipListDeviceNameColumn.Text = "Device Name";
            this.ipListDeviceNameColumn.Width = 109;
            // 
            // StatusBar1
            // 
            this.StatusBar1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.StatusBar1.Location = new System.Drawing.Point(0, 705);
            this.StatusBar1.Name = "StatusBar1";
            this.StatusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.TStatusPanel,
            this.Port,
            this.Manufacturername});
            this.StatusBar1.ShowPanels = true;
            this.StatusBar1.Size = new System.Drawing.Size(828, 22);
            this.StatusBar1.SizingGrip = false;
            this.StatusBar1.TabIndex = 26;
            this.StatusBar1.Text = "StatusBar1";
            // 
            // TStatusPanel
            // 
            this.TStatusPanel.Name = "TStatusPanel";
            this.TStatusPanel.Width = 740;
            // 
            // Port
            // 
            this.Port.MinWidth = 66;
            this.Port.Name = "Port";
            this.Port.Text = "Port:";
            // 
            // Manufacturername
            // 
            this.Manufacturername.Name = "Manufacturername";
            this.Manufacturername.Text = "statusManufacturer nameBarPanel1";
            // 
            // Timer_Test_
            // 
            this.Timer_Test_.Tick += new System.EventHandler(this.Timer_Test__Tick);
            // 
            // Timer_G2_Read
            // 
            this.Timer_G2_Read.Interval = 200;
            this.Timer_G2_Read.Tick += new System.EventHandler(this.Timer_G2_Read_Tick);
            // 
            // Timer_G2_Alarm
            // 
            this.Timer_G2_Alarm.Tick += new System.EventHandler(this.Timer_G2_Alarm_Tick);
            // 
            // Timer_Test_6B
            // 
            this.Timer_Test_6B.Tick += new System.EventHandler(this.Timer_Test_6B_Tick);
            // 
            // Timer_6B_Read
            // 
            this.Timer_6B_Read.Tick += new System.EventHandler(this.Timer_6B_Read_Tick);
            // 
            // Timer_6B_Write
            // 
            this.Timer_6B_Write.Tick += new System.EventHandler(this.Timer_6B_Write_Tick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(828, 727);
            this.Controls.Add(this.StatusBar1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Electron HW-VX6330K HW-VX6346KL v2.8";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.TabSheet_CMD.ResumeLayout(false);
            this.groupBox37.ResumeLayout(false);
            this.groupBox37.PerformLayout();
            this.groupBox41.ResumeLayout(false);
            this.groupBox41.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.groupBox34.ResumeLayout(false);
            this.groupBox34.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox32.ResumeLayout(false);
            this.groupBox32.PerformLayout();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.TabSheet_EPCC1G2.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.TabSheet_6B.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.groupBox35.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TStatusPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Port)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manufacturername)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage TabSheet_CMD;
        internal System.Windows.Forms.StatusBar StatusBar1;
        private System.Windows.Forms.StatusBarPanel TStatusPanel;
        private System.Windows.Forms.StatusBarPanel Port;
        private System.Windows.Forms.StatusBarPanel Manufacturername;
        private System.Windows.Forms.TabPage TabSheet_EPCC1G2;
        private System.Windows.Forms.TabPage TabSheet_6B;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Edit_dmaxfre;
        private System.Windows.Forms.TextBox Edit_powerdBm;
        private System.Windows.Forms.TextBox Edit_Version;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Edit_dminfre;
        private System.Windows.Forms.TextBox Edit_ComAdr;
        private System.Windows.Forms.TextBox Edit_Type;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label ProtocolLabel;
        private System.Windows.Forms.Button Button_GetReaderInfo;
        private System.Windows.Forms.TextBox Edit_scantime;
        private System.Windows.Forms.CheckBox EPCC1G2;
        private System.Windows.Forms.CheckBox ISO180006B;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ComboBox_PowerDbm;
        private System.Windows.Forms.TextBox Edit_NewComAdr;
        private System.Windows.Forms.ComboBox ComboBox_dmaxfre;
        private System.Windows.Forms.ComboBox ComboBox_dminfre;
        private System.Windows.Forms.Button Button_DefaultParameter;
        private System.Windows.Forms.Button Button_SetParameter;
        private System.Windows.Forms.ComboBox ComboBox_scantime;
        private System.Windows.Forms.ComboBox ComboBox_baud;
        private System.Windows.Forms.CheckBox CheckBox_SameFre;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton C_TID;
        private System.Windows.Forms.RadioButton C_EPC;
        private System.Windows.Forms.RadioButton C_Reserve;
        private System.Windows.Forms.RadioButton C_User;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button Button_BlockErase;
        private System.Windows.Forms.Button Button_DataWrite;
        private System.Windows.Forms.Button SpeedButton_Read_G2;
        private System.Windows.Forms.TextBox Edit_WriteData;
        private System.Windows.Forms.TextBox Edit_AccessCode2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox Edit_WordPtr;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox ComboBox_EPC1;
        private System.Windows.Forms.RadioButton AlwaysNot;
        private System.Windows.Forms.RadioButton Always;
        private System.Windows.Forms.RadioButton Proect;
        private System.Windows.Forms.RadioButton NoProect;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton AccessCode;
        private System.Windows.Forms.RadioButton DestroyCode;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton P_User;
        private System.Windows.Forms.RadioButton P_TID;
        private System.Windows.Forms.RadioButton P_EPC;
        private System.Windows.Forms.RadioButton P_Reserve;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton Always2;
        private System.Windows.Forms.RadioButton Proect2;
        private System.Windows.Forms.RadioButton NoProect2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RadioButton AlwaysNot2;
        private System.Windows.Forms.Button Button_SetProtectState;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox ComboBox_IntervalTime;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button Button_DestroyCard;
        private System.Windows.Forms.TextBox Edit_DestroyCode;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox ComboBox_EPC3;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button Button_WriteEPC_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox Edit_WriteEPC;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button Button_CheckReadProtected_G2;
        private System.Windows.Forms.Button Button_RemoveReadProtect_G2;
        private System.Windows.Forms.Button Button_SetMultiReadProtect_G2;
        private System.Windows.Forms.Button Button_SetReadProtect_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode4;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox ComboBox_EPC4;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.ComboBox ComboBox_EPC5;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox Edit_AccessCode5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.RadioButton NoAlarm_G2;
        private System.Windows.Forms.RadioButton Alarm_G2;
        private System.Windows.Forms.Button Button_CheckAlarm;
        private System.Windows.Forms.Button Button_SetEASAlarm_G2;
        private System.Windows.Forms.Label Label_Alarm;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.ComboBox ComboBox_BlockNum;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox ComboBox_EPC6;
        private System.Windows.Forms.Button Button_LockUserBlock_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode6;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.ListView ListView_ID_6B;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Button SpeedButton_Query_6B;
        private System.Windows.Forms.RadioButton Bycondition_6B;
        private System.Windows.Forms.RadioButton Byone_6B;
        private System.Windows.Forms.ComboBox ComboBox_IntervalTime_6B;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.TextBox Edit_ConditionContent_6B;
        private System.Windows.Forms.TextBox Edit_Query_StartAddress_6B;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.RadioButton Greater_6B;
        private System.Windows.Forms.RadioButton Less_6B;
        private System.Windows.Forms.RadioButton Different_6B;
        private System.Windows.Forms.RadioButton Same_6B;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox Edit_StartAddress_6B;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox ComboBox_ID1_6B;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button Button_Clear;
        private System.Windows.Forms.Button Button_Check;
        private System.Windows.Forms.Button Button_PermanentWrite;
        private System.Windows.Forms.Button SpeedButton_Write_6B;
        private System.Windows.Forms.Button SpeedButton_Read_6B;
        private System.Windows.Forms.TextBox Edit_Len_6B;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer Timer_Test_;
        private System.Windows.Forms.ComboBox ComboBox_EPC2;
        private System.Windows.Forms.Timer Timer_G2_Read;
        private System.Windows.Forms.Timer Timer_G2_Alarm;
        private System.Windows.Forms.ListView ListView1_EPC;
        private System.Windows.Forms.ColumnHeader listViewCol_Number;
        private System.Windows.Forms.ColumnHeader listViewCol_ID;
        private System.Windows.Forms.ColumnHeader listViewCol_Length;
        private System.Windows.Forms.ColumnHeader listViewCol_Times;
        private System.Windows.Forms.Button Button_QueryTag;
        private System.Windows.Forms.Timer Timer_Test_6B;
        private System.Windows.Forms.Timer Timer_6B_Read;
        private System.Windows.Forms.TextBox Edit_WriteData_6B;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Timer Timer_6B_Write;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button Button_SetWGParameter;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button Button_ClearListBox;
        private System.Windows.Forms.Button Button_GetListBox;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Button Button_SetWorkMode;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.RadioButton radioButton_band4;
        private System.Windows.Forms.RadioButton radioButton_band3;
        private System.Windows.Forms.RadioButton radioButton_band2;
        private System.Windows.Forms.RadioButton radioButton_band1;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.TextBox maskLen_textBox;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox maskadr_textbox;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.CheckBox CheckBox_EPCMaskEnabled;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button Button_SetAccuracy;
        private System.Windows.Forms.ComboBox ComboBox_EASAccuracy;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.Button button_OffsetTime;
        private System.Windows.Forms.ComboBox comboBox_OffsetTime;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button BlockWrite;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button Button_ClearFreq;
        private System.Windows.Forms.Button Button_StopFreq;
        private System.Windows.Forms.Button Button_StartFreq;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button Button_GetFreq;
        private System.Windows.Forms.Button Button_SetFreq;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.RadioButton radioButton_band5;
        private System.Windows.Forms.Button button_gettigtime;
        private System.Windows.Forms.Button button_settigtime;
        private System.Windows.Forms.ComboBox comboBox_tigtime;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.CheckBox CheckBox_TID;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox_pc;
        private System.Windows.Forms.CheckBox checkBox_pc;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.Button Button_Relay;
        private System.Windows.Forms.ComboBox ComboBox_Relay1;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.ComboBox ComboBox_Relay2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.ListView ipList;
        private System.Windows.Forms.ColumnHeader ipListNoColumn;
        private System.Windows.Forms.ColumnHeader ipListMacColumn;
        private System.Windows.Forms.ColumnHeader ipListIpColumn;
        private System.Windows.Forms.ColumnHeader ipListUsernameColumn;
        private System.Windows.Forms.Button LEDFlashButton;
        private System.Windows.Forms.Button changeIpButton;
        private System.Windows.Forms.Button configButton;
        private System.Windows.Forms.Button specificSearchButton;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.GroupBox groupBox37;
        internal System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.ComboBox ComboBox_baud2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox ComboBox_AlreadyOpenCOM;
        private System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Button ClosePort;
        internal System.Windows.Forms.Button OpenPort;
        internal System.Windows.Forms.TextBox Edit_CmdComAddr;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.ComboBox ComboBox_COM;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.Button CloseNetPort;
        private System.Windows.Forms.Button OpenNetPort;
        private System.Windows.Forms.TextBox Edit_TCPIPAddr;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox Edit_TCPIPIP;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox Edit_TCPIPPort;
        private System.Windows.Forms.Label label65;
		private System.Windows.Forms.ColumnHeader ipListDeviceNameColumn;
	}
}

