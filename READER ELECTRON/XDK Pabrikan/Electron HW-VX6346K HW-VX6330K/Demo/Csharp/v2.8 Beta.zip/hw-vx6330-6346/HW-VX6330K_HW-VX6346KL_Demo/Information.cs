﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace HwVx6330K
{
    public class Information
    {
        public static string IP = "";
        public static string usename = "";
        public static string dsname = "";
        public static string mac = "";
        public static string portnum = "";
        public static string tup = "";
        public static string rm = "";
        public static string cm = "";
        public static string ct = "";
        public static string fc = "";
        public static string dt = "";
        public static string br = "";
        public static string pr = "";
        public static string bb = "";
        public static string rc = "";
        public static string ml = "";
        public static string md = "";
        public static string di = "";
        public static string dp = "";
        public static string gi = "";
        public static string nm = "";

        public static void Clear()
        {
            Information.IP = "";
            Information.usename = "";
            Information.dsname = "";
            Information.mac = "";
            Information.portnum = "";
            Information.tup = "";
            Information.rm = "";
            Information.cm = "";
            Information.ct = "";
            Information.fc = "";
            Information.dt = "";
            Information.br = "";
            Information.pr = "";
            Information.bb = "";
            Information.rc = "";
            Information.ml = "";
            Information.md = "";
            Information.di = "";
            Information.dp = "";
            Information.gi = "";
            Information.nm = "";
        }
    }
}
